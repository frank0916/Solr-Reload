#debug.sh
get_orders()
{
  start=`date -d @${1:0:-3} +%Y-%m-%dT%H:%M:%S.${1: -3}Z`
  end=`date -d @${2:0:-3} +%Y-%m-%dT%H:%M:%S.${2: -3}Z`
  q="orderDate%3A%5B${start}%20TO%20${end}%5D"
  cnt=`curl -s --location -g --request GET "${solr_url}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
  if [[ $((cnt)) -eq 0 ]]; then
    echo 0: cnt=$cnt, start=$start, end=$end
  elif [[ $((cnt)) -le 1000 ]] || [[ $(($1))+1 -eq $(($2)) ]]; then
    echo "1000-": cnt=$cnt, start=$start, end=$end
    curl -s --location -g --request GET "${solr_url}/select?q=${q}&fl=orderNo&rows=1000" | \
    sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p'
  else
    echo "1000+": cnt=$cnt, start=$start, end=$end
    get_orders $(( ($1+$2)/2 )) $2
    get_orders $1 $(( ($1+$2)/2 ))
  fi
}


#get order number is between 2 timestamp
#modify head and tail to a specific timestamp range (in milli-seconds)
let tail=1690761600000
let head=1626825600000

// secondary solr URL of SC or WUS2
solr_url=http://solrcloud.prod-az-southcentralus.order-services-secondary-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_hist_prod

get_orders $head $tail


get_orders()
{
  start=`date -d @${1:0:-3} +%Y-%m-%dT%H:%M:%S.${1: -3}Z`
  end=`date -d @${2:0:-3} +%Y-%m-%dT%H:%M:%S.${2: -3}Z`
  q="orderDate%3A%5B${start}%20TO%20${end}%5D"
  cnt=`curl -s --location -g --request GET "${solr_url}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
  if [[ $((cnt)) -eq 0 ]]; then
    :
  elif [[ $((cnt)) -le 1000 ]] || [[ $(($1))+1 -eq $(($2)) ]]; then
    curl -s --location -g --request GET "${solr_url}/select?q=${q}&fl=orderNo&rows=1000" | \
    sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p'
  else
    get_orders $(( ($1+$2)/2 )) $2
    get_orders $1 $(( ($1+$2)/2 ))
  fi
}


while [ $tail -gt $head ]
do
  let mark=$tail-86400000
  get_orders $mark $tail >> $mark-$tail.txt
  tar zcf $mark-$tail.txt.tar.gz $mark-$tail.txt
  rm $mark-$tail.txt
  let tail=$mark
done

solr_url=http://solrcloud.prod-az-westus2.order-services-primary2-prod.ms-df-solrcloud.westus2.prod.us.walmart.net:8983/solr/purchase_orders

get_orders()
{
  start=`date -d @${1:0:-3} +%Y-%m-%dT%H:%M:%S.${1: -3}Z`
  end=`date -d @${2:0:-3} +%Y-%m-%dT%H:%M:%S.${2: -3}Z`
  q="orderDate%3A%5B${start}%20TO%20${end}%5D"
  cnt=`curl -s --location -g --request GET "${solr_url}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
  if [[ $((cnt)) -eq 0 ]]; then
    :
  elif [[ $((cnt)) -le 300 ]] || [[ $(($1))+1 -eq $(($2)) ]]; then
    curl -s --location -g --request GET "${solr_url}/select?q=${q}&fl=orderNo&rows=300" | \
    sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p'
  else
    get_orders $(( ($1+$2)/2 )) $2
    get_orders $1 $(( ($1+$2)/2 ))
  fi
}

get_orders $1 $2 > $1-$2.txt