base_url=http://solrcloud.prod-az-westus2.order-services-return-prod.ms-df-solrcloud.westus2.prod.us.walmart.net:8983/solr/return_orders
#q="orderDate:[NOW-13MONTHS%20TO%20NOW-12MONTHS]&rows=100&fl=idx"
#q='orderDate:[* TO NOW-12MONTHS] AND path:1.ReturnOrde&rows=200&fl=idx'
#q='orderDate%3A%5B*%20TO%20NOW-12MONTHS%5D%20AND%20path%3A1.ReturnOrder&rows=150&fl=idx'
#q='orderDate:[NOW-13MONTHS TO NOW-12MONTHS] AND path:1.ReturnOrder&rows=150&fl=idx'
q='orderDate%3A%5B*%20TO%20NOW-12MONTHS%5D%20AND%20path%3A1.ReturnOrder&rows=150&fl=idx'
part1="curl -s -X POST -H 'Content-Type: application/xml' '${base_url}/update' -d '<delete><query>"
part3="</query></delete>'"
while true; do
    hour=`date +%H`
    [[ ${hour} -lt 3 || ${hour} -gt 11 ]] && sleep 600 && continue
    part2=`curl -s --location -g --request GET "${base_url}/select?q=${q}" | sed -n 's/^ *"idx":"\([^"]*\)".*/_root_:\1/p' | paste -sd ' ' - | sed -e 's/ / OR /g'`
    [ -z "${part2}" ] || eval ${part1}${part2}${part3}
    sleep 10
done


