// 1. save sample payload from os lookup to order.json file
// 2. save this file to index.js
// 3. run command to redirect output to output.txt
//   node index.js > output.txt
// 4. join lines in output.txt file in one line
//   paste -sd',' output.txt > output.oneline.txt

const orders = require('./order.json').payload;

const lines = new Set()

const log = function(parents, name) {
  let line = `${parents.length}.${parents.join(".")}.${name}`

  if (lines.has(line)) return

  lines.add(line)
}

const traverse = function(node, parents) {
  for (let child in node) {

    let isNum = /^\d/.test(child)
    !isNum && log(parents, child)

    let value = node[child]

    if (typeof value == "object") {
      traverse(value, isNum ? parents : parents.concat(child))
    }
  }
}

for (let i in orders) {
  let order = orders[i]
  traverse(order, ['Order'])
}

for (let line of lines) {
  console.log(line)
}