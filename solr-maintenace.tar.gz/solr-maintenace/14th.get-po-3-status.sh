solr_url=http://solrcloud.prod-az-westus2.order-services-primary2-prod.ms-df-solrcloud.westus2.prod.us.walmart.net:8983/solr/purchase_orders

get_pos()
{
  start=`date -d @${1:0:-3} +%Y-%m-%dT%H:%M:%S.${1: -3}Z`
  end=`date -d @${2:0:-3} +%Y-%m-%dT%H:%M:%S.${2: -3}Z`
  q="orderDate%3A%5B${start}%20TO%20${end}%5D%"
  cnt=`curl -s --location -g --request GET "${solr_url}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
  if [[ $((cnt)) -eq 0 ]]; then
    :
  elif [[ $((cnt)) -le 300 ]] || [[ $(($1))+1 -eq $(($2)) ]]; then
    curl -s --location -g --request GET "${solr_url}/select?q=${q}&fl=orderNo&rows=300"
  else
    get_pos $(( ($1+$2)/2 )) $2
    get_pos $1 $(( ($1+$2)/2 ))
  fi
}

get_pos $1 $2 > $1-$2.txt

curl -s --location 'http://orders-app.prod.walmart.com/orders-lookup/services/v4/orders/?fromOrderDate=NOW-1DAYS&toOrderDate=NOW' \
--header 'Accept: application/json' \
--header 'Content-Type: application/json' \
--header 'WM_QOS.CORRELATION_ID: 2323' \
--header 'WM_SVC.VERSION: 1.0.0' \
--header 'WM_SVC.ENV: dev' \
--header 'WM_SVC.NAME: order-service' \
--header 'WM_CONSUMER.ID: 2d0a30c7-b4cc-45d1-b451-d93535f5a92d' \
--header 'WM_CONSUMER.TENANT_ID: 0' | json_pp | grep -i \"status\" | awk -F\" '{print $4}'


get_orders()
{
  start=`date -d @${1:0:-3} +%Y-%m-%dT%H:%M:%S.${1: -3}Z`
  end=`date -d @${2:0:-3} +%Y-%m-%dT%H:%M:%S.${2: -3}Z`
  q="orderDate%3A%5B${start}%20TO%20${end}%5D"
  cnt=`curl -s --location -g --request GET "${solr_url}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
  if [[ $((cnt)) -eq 0 ]]; then
    :
  elif [[ $((cnt)) -le 300 ]] || [[ $(($1))+1 -eq $(($2)) ]]; then
    curl -s --location -g --request GET "${solr_url}/select?q=${q}&fl=orderNo&rows=300" | \
    sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p'
  else
    get_orders $(( ($1+$2)/2 )) $2
    get_orders $1 $(( ($1+$2)/2 ))
  fi
}
