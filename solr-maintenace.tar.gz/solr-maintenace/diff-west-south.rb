#!/usr/bin/ruby
require 'json'
require 'net/https'
require 'date'

#howLongMonths=6
frequencyInDays=1
endDate = Date.today
#startDate = Date.today << howLongMonths
startDate = Date.today-7
while startDate < endDate do	
  startDateFilter = startDate+1
  endDateFilter = startDate+frequencyInDays

  
  filter="orderDate:[#{startDateFilter}T00:00:00Z TO #{endDateFilter}T23:59:59Z] AND isTestMode: false"
  resp_cluster_1=`curl -s "http://solrcloud.prod-az-southcentralus.order-services-secondary-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_hist_prod/query?fl=id" -d '{ params: { q: "#{filter}",rows: 0 } }'`
  cluster_1_obj = JSON.parse(resp_cluster_1)	
  cluster_1_num = cluster_1_obj['response']['numFound']
  
  resp_cluster_2=`curl -s "http://solrcloud.prod-az-westus2.order-services-secondary-prod.ms-df-solrcloud.westus2.prod.us.walmart.net:8983/solr/orders_hist_prod/query?fl=id" -d '{ params: { q: "#{filter}",rows: 0 } }'`
  cluster_2_obj = JSON.parse(resp_cluster_2)	
  cluster_2_num = cluster_2_obj["response"]["numFound"]
  diff = cluster_2_num.to_i - cluster_1_num.to_i
  
  puts  "#{filter} : #{cluster_2_num} : #{cluster_1_num} Secondary Solr diff =  #{diff}" if diff != 0

  startDate = endDateFilter
end 
