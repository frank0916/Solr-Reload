#step 1 create keyspace and table
#https://cassandra.apache.org/_/quickstart.html
#latest cqlversion='3.4.6' at moment of writing this script
docker run --rm -it --network cassandra nuvo/docker-cqlsh cqlsh cassandra 9042 --cqlversion='3.4.6'
#then run the sql in cql terminal

CREATE KEYSPACE order_services_stage
 WITH replication = {'class' : 'SimpleStrategy', 
  'replication_factor' : 1 
 };

use order_services_stage;

CREATE TABLE order_services_stage.orderdata (
    order_no text PRIMARY KEY,
    compressed_data text,
    data text,
    event_time timestamp,
    order_source text,
    order_type text,
    order_version int,
    shard_id int,
    src_created_dt timestamp,
    src_modified_dt timestamp,
    tenant_id text,
    test_order boolean,
    vertical_id text
) WITH additional_write_policy = '99p'
    AND bloom_filter_fp_chance = 0.01
    AND caching = {'keys': 'ALL', 'rows_per_partition': 'NONE'}
    AND cdc = false
    AND comment = 'Setting dc local read repair, read repair'
    AND compaction = {'class': 'org.apache.cassandra.db.compaction.SizeTieredCompactionStrategy', 'max_threshold': '12', 'min_threshold': '3'}
    AND compression = {'chunk_length_in_kb': '64', 'class': 'org.apache.cassandra.io.compress.LZ4Compressor'}
    AND crc_check_chance = 1.0
    AND default_time_to_live = 0
    AND extensions = {}
    AND gc_grace_seconds = 864000
    AND max_index_interval = 2048
    AND memtable_flush_period_in_ms = 0
    AND min_index_interval = 128
    AND read_repair = 'BLOCKING'
    AND speculative_retry = '99p';

#step 2 create scala 2 project
https://docs.scala-lang.org/getting-started/sbt-track/getting-started-with-scala-and-sbt-on-the-command-line.html

sbt new scala/hello-world.g8
#https://spark.apache.org/docs/latest/quick-start.html#self-contained-applications
#add libraryDependencies += "org.apache.spark" %% "spark-sql" % "3.4.1" to build.sbt
