// 1. run curl save 300 production orders to orders.json
// curl -s --location --request GET 'http://orders-app.prod.order-services.cp.prod.walmart.com/orders-lookup/services/v4/orders?fromOrderDate=NOW-1DAYS&toOrderDate=NOW&limit=300' \
// --header 'Accept: application/json' \
// --header 'Content-Type: application/json' \
// --header 'WM_QOS.CORRELATION_ID: 2323' \
// --header 'WM_SVC.VERSION: 1.0.0' \
// --header 'WM_SVC.ENV: dev' \
// --header 'WM_SVC.NAME: order-service' \
// --header 'WM_CONSUMER.ID: 2d0a30c7-b4cc-45d1-b451-d93535f5a92d' \
// --header 'WM_CONSUMER.TENANT_ID: 0' | json_pp
// 2. save this file to index2.js
// 3. run command to redirect output to output.txt
//   node index2.js > output2.txt
// 4. join lines in output2.txt file in one line
//   paste -sd',' output2.txt > output2.oneline.txt

const orders = require('./orders.json').payload;

const lines = new Set()

const log = function(parents, name) {
  let line = `${parents.length}.${parents.join(".")}.${name}`

  if (lines.has(line)) return

  lines.add(line)

  console.log(line)
}

const traverse = function(node, parents) {
  for (let child in node) {

    let isNum = /^\d/.test(child)
    !isNum && log(parents, child)

    let value = node[child]

    if (typeof value == "object") {
      traverse(value, isNum ? parents : parents.concat(child))
    }
  }
}

for (let order of orders) {
  traverse(order, ['Order'])
}

