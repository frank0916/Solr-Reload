to_json() {
  while read order_no
  do
    echo '{event_id:"'$order_no'",event_name:"RELOAD_ORDERS",event_source:"OMSNEXT"}'
  done
}

solr_url=http://solrcloud.stg-az-southcentralus.order-services3-stg.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_teflon

get_orders()
{
  start=`date -d @${1:0:-3} +%Y-%m-%dT%H:%M:%S.${1: -3}Z`
  end=`date -d @${2:0:-3} +%Y-%m-%dT%H:%M:%S.${2: -3}Z`
  q="orderDate%3A%5B${start}%20TO%20${end}%5D"
  cnt=`curl -s --location -g --request GET "${solr_url}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
  if [[ $((cnt)) -eq 0 ]]; then
    :
  elif [[ $((cnt)) -le 1000 ]]; then
    curl -s --location -g --request GET "${solr_url}/select?q=${q}&fl=orderNo&rows=1000" | \
    sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p'
  elif [[ $(($1))+1 -ge $(($2)) ]]; then
    let loops=$cnt/1000
    while [ $loops -ge 0 ]
    do
      let offset=$loops*1000
      curl -s --location -g --request GET "${solr_url}/select?q=${q}&fl=orderNo&rows=1000&offset=${offset}" | \
      sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p'
      let loops=$loops-1
    done
  else
    get_orders $(( ($1+$2)/2 )) $2
    get_orders $1 $(( ($1+$2)/2 ))
  fi
}

get_orders $1 $2 | to_json | \
bin/kafka-console-producer.sh \
  --topic us-orders_teflon \
  --bootstrap-server kafka-1301504412-3-1354806781.scus.kafka-v2-oms-sox-teflon-stg.ms-df-messaging.stg-az-southcentralus-10.prod.us.walmart.net:9093,kafka-1301504412-2-1354806778.scus.kafka-v2-oms-sox-teflon-stg.ms-df-messaging.stg-az-southcentralus-10.prod.us.walmart.net:9093,kafka-1301504412-4-1354806784.scus.kafka-v2-oms-sox-teflon-stg.ms-df-messaging.stg-az-southcentralus-10.prod.us.walmart.net:9093,kafka-1301504412-5-1354806787.scus.kafka-v2-oms-sox-teflon-stg.ms-df-messaging.stg-az-southcentralus-10.prod.us.walmart.net:9093,kafka-1301504412-1-1354806775.scus.kafka-v2-oms-sox-teflon-stg.ms-df-messaging.stg-az-southcentralus-10.prod.us.walmart.net:9093,kafka-1301504412-6-1354806790.scus.kafka-v2-oms-sox-teflon-stg.ms-df-messaging.stg-az-southcentralus-10.prod.us.walmart.net:9093

# ssh 10.12.160.31 # host to run this script
# ps -ef | grep order.reload.sh # command to find pid of this script
# date +%s # command to print system time in seconds
# date +%s -d"Jan 1, 1980 00:00:01" # covert string to time
# date +%s -ud"Jan 1, 1980 00:00:01" # covert string GMT/UTC time
# date -d @${$1} +%Y-%m-%dT%H:%M:%SZ # convert seconds to Solr time format
# date -d @${1:0:-3} +%Y-%m-%dT%H:%M:%S.${1: -3}Z # ms to Solr time format
# get orderNo from Solr and publish message to data-load-order-us topic
# insertAllOrder in ConsumerBizImpl.insertAllOrder(String message)
# '{event_id:"'$line'",event_name:"RELOAD_ORDERS",event_source:"OMSNEXT"}'

# -bash-4.2$ nohup ./batch.sh >/dev/null 2>&1 &
# [1] 7007

# macos version
# get_orders()
# {
#   start=`date -d @${1:0:-3} +%Y-%m-%dT%H:%M:%S.${1: -3}Z`
#   end=`date -d @${2:0:-3} +%Y-%m-%dT%H:%M:%S.${2: -3}Z`
#   q="orderDate%3A%5B${start}%20TO%20${end}%5D"
#   cnt=`curl -s --location -g --request GET "${solr_url}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
#   if [[ $((cnt)) -eq 0 ]]; then
#     :
#   elif [[ $((cnt)) -le 1000 ]]; then
#     curl -s --location -g --request GET "${solr_url}/select?q=${q}&fl=orderNo&rows=1000" | \
#     sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p'
#   elif [[ $(($1))+1 -ge $(($2)) ]]; then
#     let loops=$cnt/1000
#     while [ $loops -ge 0 ]
#     do
#       let offset=$loops*1000
#       curl -s --location -g --request GET "${solr_url}/select?q=${q}&fl=orderNo&rows=1000&offset=${offset}" | \
#       sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p'
#       let loops=$loops-1
#     done
#   else
#     get_orders $(( ($1+$2)/2 )) $2
#     get_orders $1 $(( ($1+$2)/2 ))
#   fi
# }
