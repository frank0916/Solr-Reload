#setup 2 tables by following instruction here -> https://anant.us/blog/modern-business/data-operations-with-spark-and-cassandra/

#step one setup
cd spark-3.4.1-bin-hadoop3
./sbin/start-master.sh
#spark://m-c02zd34clvdq:7077
./sbin/start-slave.sh spark://m-c02zd34clvdq:7077


./bin/spark-shell --packages com.datastax.spark:spark-cassandra-connector_2.12:3.3.0 \
--master spark://m-c02zd34clvdq:7077 \
--conf spark.cassandra.connection.host=127.0.0.1 \
--conf spark.cassandra.connection.port=9042 \
--conf spark.sql.extensions=com.datastax.spark.connector.CassandraSparkExtensions

#start docker and cassandra
docker run --name cassandra -p 9042:9042 -d cassandra:latest

#start CQLSH terminal
docker exec -it cassandra bash
cqlsh


#if keyspace demo does not exist, create it
CREATE KEYSPACE demo WITH REPLICATION={'class': 'SimpleStrategy', 'replication_factor': 1};
use demo;

#create table spacecraft_journey_catalog_1, spacecraft_journey_catalog_3 if they are not existing
CREATE TABLE IF NOT EXISTS spacecraft_journey_catalog (
    spacecraft_name text,
    journey_id timeuuid,
    start timestamp,
    end timestamp,
    active boolean,
    summary text,
    PRIMARY KEY ((spacecraft_name), journey_id)
) WITH CLUSTERING ORDER BY (journey_id desc);

CREATE TABLE IF NOT EXISTS spacecraft_journey_catalog_1 (
  	spacecraft_name text,
  	journey_id timeuuid,
  	start timestamp,
  	end timestamp,
  	active boolean,
  	summary text,
  	PRIMARY KEY ((spacecraft_name), journey_id)
) WITH CLUSTERING ORDER BY (journey_id desc);


CREATE TABLE IF NOT EXISTS spacecraft_journey_catalog_3 (
  	spacecraft_name text,
  	journey_id timeuuid,
  	start timestamp,
  	end timestamp,
  	active boolean,
  	summary text,
  	PRIMARY KEY ((spacecraft_name), journey_id)
) WITH CLUSTERING ORDER BY (journey_id desc);

#truncate table if they have rows
truncate table spacecraft_journey_catalog;
truncate table spacecraft_journey_catalog3;

#load data to from https://blog.anant.us/wp-content/uploads/2021/01/data.txt

#step 2 start spark-shell

./bin/spark-shell --packages com.datastax.spark:spark-cassandra-connector_2.12:3.0.0 \
--master <Spark master URL> \
--conf spark.cassandra.connection.host=127.0.0.1 \
--conf spark.cassandra.connection.port=9042 \
--conf spark.sql.extensions=com.datastax.spark.connector.CassandraSparkExtensions


#option one use spark.sql to copy table
//Catalog Cass100 for Cluster at 127.0.0.1
spark.conf.set(s"spark.sql.catalog.cass100", "com.datastax.spark.connector.datasource.CassandraCatalog")
spark.conf.set(s"spark.sql.catalog.cass100.spark.cassandra.connection.host", "127.0.0.1")

//Catalog Cass200 for Cluster at 127.0.0.1
spark.conf.set(s"spark.sql.catalog.cass200", "com.datastax.spark.connector.datasource.CassandraCatalog")
spark.conf.set(s"spark.sql.catalog.cass100.spark.cassandra.connection.host", "127.0.0.1")

spark.sql("INSERT INTO cass200.demo.spacecraft_journey_catalog_2 SELECT * from cass100.demo.spacecraft_journey_catalog_1")


#option two use scala to copy table
import org.apache.spark.sql.functions._
import com.datastax.spark.connector._
import org.apache.spark.sql.cassandra._
import com.datastax.spark.connector.cql._
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import com.datastax.spark.connector._


def twoClusterExample ( sc: SparkContext ) = {
  //https://javadoc.io/doc/com.datastax.spark/spark-cassandra-connector_2.10/1.2.0/com/datastax/spark/connector/cql/CassandraConnector.html
  //https://javadoc.io/doc/com.datastax.spark/spark-cassandra-connector_2.10/1.2.0/com/datastax/spark/connector/cql/CassandraConnectorConf.html
  val connectorToClusterOne = CassandraConnector(sc.getConf.set("spark.cassandra.connection.host", "127.0.0.1"))
  val connectorToClusterTwo = CassandraConnector(sc.getConf.set("spark.cassandra.connection.host", "127.0.0.1"))

  val rddFromClusterOne = {
    implicit val c = connectorToClusterOne
    sc.cassandraTable("demo","spacecraft_journey_catalog")
  }

  {
    implicit val c = connectorToClusterTwo
    rddFromClusterOne.saveToCassandra("demo","spacecraft_journey_catalog_3")
  }
}

val context = SparkContext.getOrCreate;
twoClusterExample(context)


