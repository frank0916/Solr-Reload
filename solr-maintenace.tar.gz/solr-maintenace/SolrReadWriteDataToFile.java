package com.walmart.scos.services.orders.biz.test;

import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.DefaultConnectionReuseStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultConnectionKeepAliveStrategy;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrQuery.ORDER;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.CloudSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;

import java.io.*;
import java.util.concurrent.TimeUnit;

/**
 * File created by Ahmed Hamdy at 6/23/2021.
 */
public class SolrReadWriteDataToFile {

    //Secondary Solr that get the order # list, this is just sameple zookeeper list
    private final static String sec_solr_zkHost = "solr-zk--1-861133613..order-services-secondary2-prod.ms-df-solrcloud.prod.us.walmart.net:2181,solr-zk--2-861133616..order-services-secondary2-prod.ms-df-solrcloud.prod.us.walmart.net:2181,solr-zk--3-861133619..order-services-secondary2-prod.ms-df-solrcloud.prod.us.walmart.net:2181,solr-zk--4-861133622..order-services-secondary2-prod.ms-df-solrcloud.prod.us.walmart.net:2181,solr-zk--5-861133625..order-services-secondary2-prod.ms-df-solrcloud.prod.us.walmart.net:2181,solr-zk--6-861133628..order-services-secondary2-prod.ms-df-solrcloud.prod.us.walmart.net:2181";
    private final static String sec_solr_collection_name = "orders_hist_prod";
    private final static Integer sec_max_rows = 1000;
    private final static Integer sec_max_offset = 100000;
    @SuppressWarnings("deprecation")
    static CloudSolrClient secondary_solrClient = new CloudSolrClient.Builder().withZkHost(sec_solr_zkHost).withHttpClient(getHttpClient()).build();

//    String search_query = "orderDate:[2020-04-27T00:00:00Z-28800SECONDS TO 2020-04-27T00:00:00Z-0SECONDS]";
//    String search_query = "orderDate:[2020-04-27T00:00:00Z-28800+28800SECONDS TO 2020-04-27T00:00:00Z-28800SECONDS]";

    /** CHANGE HERE */
    private static String read_start_date = "2021-01-23T00:00:00Z";
    //private static String read_start_date = "2020-12-23T00:00:00Z";

    private static Integer query_interval = 3600; // s - keep say 60 minutes

    /** CHANGE HERE */
    private static Integer to_range = 31 * 24 * 60 * 60; // 2 months 2 days
    //private static Integer to_range = 26 * 24 * 60 * 60; // 2 months 2 days

    private static Integer from_range = 0;
    private static long overall_Count = 0L;

    /** CHANGE HERE */
    static File fout = new File("GR-Orders-Docs-Delete-12-23-2020-to-01-23-2021.txt"); // 31
    //static File fout = new File("All-Orders-Docs-Delete-11-27-2020-to-12-23-2020.txt"); // 26

    static FileOutputStream fos;

    static {
        try {
            fos = new FileOutputStream(fout);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    static OutputStreamWriter osw = new OutputStreamWriter(fos);

    public static void main(String [] args) throws IOException, SolrServerException, Exception {
        solrDocDeletion();
        System.out.println("\nTerminating the program in 10 secs");
        Thread.sleep(10000);
        System.exit(-5);
    }

    public static void  solrDocDeletion() throws SolrServerException, IOException {
        long start = System.currentTimeMillis();
        try {
            long startTime = System.currentTimeMillis();
            for (int days = from_range; days < to_range; days = days + query_interval) {
                getSearchQueryRanges(read_start_date, days, days + query_interval);
            }
            long endTime = System.currentTimeMillis();

            System.out.println("Total Time to fetch the query: " + (endTime - startTime));

        } catch (Exception e){
            System.out.println("Exception " + e.getMessage());
        } finally {
            osw.close();
            fos.close();
        }
    }

    private static void getSearchQueryRanges(String startDate, int from, int to ) throws IOException, SolrServerException {

        String searchQuery = getSearchQuery(startDate,from,to);
        SolrQuery searchQuerySolr = new SolrQuery(searchQuery);

        // querying the orderNos from Secondary as the number of rows is higher in secondary
        long count = secondary_solrClient.query(sec_solr_collection_name,searchQuerySolr).getResults().getNumFound();
        int iteration = (int) (count/sec_max_rows) +1;

        if (sec_max_offset<count || iteration > sec_max_offset/sec_max_rows){
            System.out.println("Order Count " + count + " is higher than collection's offset " + sec_max_offset);
            int interval  = (to - from)/2;
            getSearchQueryRanges(startDate, from,from+interval);
            getSearchQueryRanges(startDate, from+interval, to);
        } else if(count > 0){
            overall_Count += count;
            searchQuerySolr.setRows(sec_max_rows);
            searchQuerySolr.addSort("orderNo", ORDER.desc);
            searchQuerySolr.setParam("fl", "orderNo");
            System.out.println("Count= " + count + " total iterations =" + iteration + " for Date Range : " +searchQuery);
            searchDocs(searchQuerySolr,count);
        }
    }

    private static void searchDocs(SolrQuery searchQuerySolr, long count) {
        try{
            for(int offset =0 ; offset<count; offset=offset+sec_max_rows){
                searchQuerySolr.setStart(offset);
                QueryResponse response = secondary_solrClient.query(sec_solr_collection_name,searchQuerySolr);
                for (SolrDocument order : response.getResults()) {
                    osw.write((String) order.getFieldValue("orderNo"));
                    osw.write("\n");
                }
            }
            System.out.println();
            System.out.println();
        } catch (Exception e){
            System.out.println("Exception: "+ e.getMessage() +  " Other : " + e.toString());
        }
    }

    private static String getSearchQuery(String startDate, int from,int to) {

        /** CHANGE HERE */
        String search_query = "orderDate:[@-#SECONDS TO @-#SECONDS] AND isTestMode:false AND verticalId:2";
        //String search_query = "orderDate:[@-#SECONDS TO @-#SECONDS] AND isTestMode:false";

        search_query = search_query.replaceAll("@", startDate);
        search_query = search_query.replaceFirst("#", String.valueOf(to));
        search_query = search_query.replaceFirst("#",String.valueOf(from));
        return search_query;
    }

    private static HttpClient getHttpClient() {
        RequestConfig rc = RequestConfig.custom().setConnectTimeout(500000)
                .setConnectionRequestTimeout(500000)
                .setSocketTimeout(500000).build();
        HttpClientBuilder httpClientBuilder = HttpClients.custom()
                .setDefaultRequestConfig(rc)
                .disableAutomaticRetries()
                .setConnectionReuseStrategy(new DefaultConnectionReuseStrategy())
                .setKeepAliveStrategy(new DefaultConnectionKeepAliveStrategy())
                .setConnectionTimeToLive(1, TimeUnit.MINUTES);
        CloseableHttpClient httpClient =  httpClientBuilder.build();
        return httpClient;
    }
}