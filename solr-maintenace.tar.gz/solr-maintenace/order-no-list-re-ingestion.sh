reingest() {
  payload='{"payload":{"martId":"0","tenantId":"0","orderNo":"'$1'","publishToOS":true,"publishToODS":false}}'
  curl -s --location 'http://pg-oms-ingestion-order.oms-order-ingestion.qa-int.k8s.walmart.net/ingestion/v1/order/snapshot/${1}' \
  --header 'Accept: application/json' \
  --header 'Accept-Encoding: text' \
  --header 'Cache-Control: no-cache' \
  --header 'Connection: keep-alive' \
  --header 'Content-Type: application/json' \
  --header 'Postman-Token: 96c953cd-ed4e-49c4-aaf3-6e54f44f42f2,ff74d75d-6511-4a65-ba2f-4b8ead9a8e96' \
  --header 'WM_CONSUMER.TENANT_ID: 0' \
  --header 'cache-control: no-cache,no-cache,no-cache' \
  --data ${payload} > /dev/null
} 

while read line; do
reingest $line
done < order_no.txt
