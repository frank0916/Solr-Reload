# this script takes 2 parameter of milliseconds
# $1 start time in milli seconds 2024-12-11T00:00:00Z
# $2 end time in milli seconds 2025-06-09T00:00:00Z

base_url=http://solrcloud.prod-wmt-uscentral.order-services-internal-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/purchase_orders

>log.txt

write_po_numbers()
{
    cursorMark=*
    while true; do
        response=`curl -s -X GET "$base_url/select?&q=$q&cursorMark=${cursorMark}"`
        echo $response >> log.txt
        nextCursorMark=$(echo "$response" | sed -n 's/.*"nextCursorMark":"\([^"]*\)".*/\1/p')
        echo debug nextCursorMark=$nextCursorMark >> log.txt
        [[ -e ${nextCursorMark} || "${nextCursorMark}" == "${cursorMark}" ]] && break
        cursorMark=${nextCursorMark}
        echo ${response} | grep -oE '"purchaseOrderNo":"[0-9A-Za-z]*' | awk -F'"' '{print $4}'
        echo cursorMark assignment cursorMark=$cursorMark >> log.txt
    done
}

echo $1 $2
q="orderDate%3A%5B$$1%20TO%20$2%5D%20AND%20poLineStatus%3A(CANCELLED%20SHIPPED%20DELIVERED)&sort=purchaseOrderNo%20asc&fl=purchaseOrderNo&rows=300"
#orderDate%3A%5BNOW-10DAYS%20TO%20NOW%5D%20AND%20poLineStatus%3A(CANCELLED%20SHIPPED%20DELIVERED)

write_po_numbers ${1} ${2}
