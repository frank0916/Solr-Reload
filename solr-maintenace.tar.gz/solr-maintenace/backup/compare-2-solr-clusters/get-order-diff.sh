#!/bin/bash

# this script takes 2 parameter of milliseconds
# $1 start time in milli seconds 2024-12-11T00:00:00Z
# $2 end time in milli seconds 2025-06-09T00:00:00Z

solr_url_1=http://solrcloud.prod-wmt-uscentral.order-services-internal-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
solr_url_2=http://solrcloud.prod-az-southcentralus.order-services-primary2-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_prod_new

max_rows=1000

>all.txt

get_orders()
{
  start=`date -d @${1:0:-3} +%Y-%m-%dT%H:%M:%S.${1: -3}Z`
  end=`date -d @${2:0:-3} +%Y-%m-%dT%H:%M:%S.${2: -3}Z`

  #echo timestamps $start, $end

  q="orderDate%3A%5B${start}%20TO%20${end}%5D"
  
  #echo curl -s --location -g --request GET "${solr_url_1}/select?q=${q}&rows=0"
  #echo curl -s --location -g --request GET "${solr_url_2}/select?q=${q}&rows=0"

  cnt_1=`curl -s --location -g --request GET "${solr_url_1}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
  cnt_2=`curl -s --location -g --request GET "${solr_url_2}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`

  #echo counts $cnt_1, $cnt_2

  if [[ $((cnt_1)) -eq $((cnt_2)) ]]; then
    :
  elif [[ $cnt_1 -lt $max_rows ]] && [[ $cnt_2 -lt $max_rows ]] || [[ $(($1))+1 -eq $(($2)) ]]; then
    curl -s --location -g --request GET "${solr_url_1}/select?q=${q}&fl=orderNo&rows=${max_rows}" | \
      sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p' > orders.1.txt
    curl -s --location -g --request GET "${solr_url_2}/select?q=${q}&fl=orderNo&rows=${max_rows}" | \
      sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p' > orders.2.txt
    sort orders.1.txt | uniq > orders.1.u.txt
    sort orders.2.txt | uniq > orders.2.u.txt
    comm -3 orders.1.u.txt orders.2.u.txt >> all.txt
  else
    get_orders $(( ($1+$2)/2 )) $2
    get_orders $1 $(( ($1+$2)/2 ))
  fi
}

start_second=$(date -d "$1" +%s)
end_second=$(date -d "$2" +%s)

get_orders ${start_second}000 ${end_second}000