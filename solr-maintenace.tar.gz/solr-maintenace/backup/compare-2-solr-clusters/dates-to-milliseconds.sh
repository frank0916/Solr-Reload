while read start end;
do
    start_ts=`date -d $start +"%s"`
    end_ts=`date -d $end +"%s"`
    echo ${start_ts}000 ${end_ts}000
done < dates.txt

