#! /bin/bash

# this script takes 2 parameter of milliseconds
# $1 start time in milli seconds 2025-01-01
# $2 end time in milli seconds 2025-06-09

solr_url_1=http://solrcloud.prod-wmt-uscentral.order-service-customer-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_hist_prod
solr_url_2=http://solrcloud.prod-wmt-uswest.order-service-customer-fb-prod.ms-df-solrcloud.us-west2.us.walmart.net:8983/solr/orders_hist_prod

start_date=$(date -d "$1" +%Y-%m-%d)
end_date=$(date -d "$2" +%Y-%m-%d)


while [[ "$start_date" < "$end_date" ]]
do
  next_date=$(date -d "$start_date +1 day" +%Y-%m-%d)
	q="orderDate%3A%5B${start_date}T00:00:00Z%20TO%20${next_date}T00:00:00Z%5D"
	cnt_1=`curl -s --location -g --request GET "${solr_url_1}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
	cnt_2=`curl -s --location -g --request GET "${solr_url_2}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
	result=$([ "$cnt_1" == "$cnt_2" ] && echo PASS || echo FAIL)
	echo $start_date - $next_date : $cnt_1 vs $cnt_2 - $result
	start_date=$next_date
done
