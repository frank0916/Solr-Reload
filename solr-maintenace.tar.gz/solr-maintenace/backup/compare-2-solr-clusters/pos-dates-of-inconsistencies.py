import requests
import json
from datetime import timedelta, date


# internal main & fallback vs sc-dr
url_1 = 'http://solrcloud.prod-wmt-uscentral.order-services-internal-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/purchase_orders/select'
url_2 = 'http://solrcloud.prod-cdc.order-services-primary-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/purchase_orders/select'

to_day = date.today()
for i in range(180):
    from_day = to_day - timedelta(1)
    params = {
        'q': f'orderDate:[{from_day}T00:00:00Z TO {to_day}T00:00:00Z]',
        #'q': f'orderDate:[{from_day}T00:00:00Z TO {to_day}T00:00:00Z] AND poLineStatus:CANCELLED',
        #'q': f'orderDate:[{from_day}T00:00:00Z TO {to_day}T00:00:00Z] AND poLineStatus:DELIVERED',
        #'q': f'orderDate:[{from_day}T00:00:00Z TO {to_day}T00:00:00Z] AND poLineStatus:PROCESSING',
        # 'q': f'orderDate:[{from_day}T00:00:00Z TO {to_day}T00:00:00Z] AND -poLineStatusCode:(1086.6 OR 9000)',
        # 'q': f'orderDate:[{from_day}T00:00:00Z TO {to_day}T00:00:00Z] AND poLineStatusCode:(3 OR 5 OR 29 OR 1100.200 OR 6 OR 63 OR 197 OR 198 OR 199 OR 200 OR 343 OR 1100.300 OR 1100.400 OR 1100.450 OR 1100.500 OR 1100.600 OR 2100.300)',
        'rows':0
    }
    response_1 = requests.get(
        url_1,
        params=params
    )
    response_2 = requests.get(
        url_2,
        params=params
    )

    json_1 = json.loads(response_1.text)
    json_2 = json.loads(response_2.text)

    cnt_1 = json_1['response']['numFound']
    cnt_2 = json_2['response']['numFound']

    diff = cnt_1 - cnt_2

    # if diff < 0:
    #     print(diff, from_day, to_day, cnt_1, cnt_2)

    if diff < -100:
        print(from_day, to_day)

    to_day = from_day
