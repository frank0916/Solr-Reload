# input this script takes 2 parameter
# $1 start date-time in the format of yyyy-MM-ddThh:mm:ssZ
# $2 end date-time in the format of yyyy-MM-ddThh:mm:ssZ
# output - missing return order number in cluster 2 will be written to missing-return-orders.txt

solr_url_1=http://solrcloud.prod-az-southcentralus.order-services-return-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/return_orders
solr_url_2=http://solrcloud.prod-az-westus2.order-services-return-prod.ms-df-solrcloud.westus2.prod.us.walmart.net:8983/solr/return_orders

max_rows=500

>log.txt
>error.txt
>missing-return-orders.txt

get_return_orders()
{
  start=`date -d @${1} +%Y-%m-%dT%H:%M:%SZ`
  end=`date -d @${2} +%Y-%m-%dT%H:%M:%SZ`

  #echo timestamps $start, $end
  q="path%3A1.ReturnOrder%20AND%20lastModified%3A%5B${start}%20TO%20${end}%5D"
  
  #echo curl -s --location -g --request GET "${solr_url_1}/select?q=${q}&rows=0"
  #echo curl -s --location -g --request GET "${solr_url_2}/select?q=${q}&rows=0"

  cnt_1=`curl -s --location -g --request GET "${solr_url_1}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
  cnt_2=`curl -s --location -g --request GET "${solr_url_2}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`

  #echo counts $cnt_1, $cnt_2

  if [[ $((cnt_1)) -eq $((cnt_2)) ]]; then
    echo from $start to $end count matches $cnt_1 == $cnt_2 >> log.txt
  elif [[ $cnt_1 -lt $max_rows ]] && [[ $cnt_2 -lt $max_rows ]]; then
    curl -s --location -g --request GET "${solr_url_1}/select?q=${q}&fl=returnOrderNo&rows=${max_rows}" | \
      sed -n 's/^ *"returnOrderNo":"\([^"]*\).*/\1/p' > orders.1.txt
    curl -s --location -g --request GET "${solr_url_2}/select?q=${q}&fl=returnOrderNo&rows=${max_rows}" | \
      sed -n 's/^ *"returnOrderNo":"\([^"]*\).*/\1/p' > orders.2.txt
    sort orders.1.txt | uniq > orders.1.u.txt
    sort orders.2.txt | uniq > orders.2.u.txt
    comm -23 orders.1.u.txt orders.2.u.txt >> missing-return-orders.txt
  elif [[ $(($1))+1 -eq $(($2)) ]]; then
    echo from $start to $end too many return orders in one second $1 $2 >> error.txt
  else
    get_return_orders $(( ($1+$2)/2 )) $2
    get_return_orders $1 $(( ($1+$2)/2 ))
  fi
}

start_second=$(date -d "${1}" +%s)
end_second=$(date -d "${2}" +%s)

get_return_orders ${start_second} ${end_second}

