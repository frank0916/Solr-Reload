#! /bin/bash

function write_orders() {
    cursorMark=*
    while true; do
        response=`curl -s -X GET "$base_url/select?&q=$q&cursorMark=${cursorMark}"`
        #echo $response >> logs/log.txt
        nextCursorMark=$(echo "$response" | sed -n 's/.*"nextCursorMark":"\([^"]*\)".*/\1/p')
        #echo debug nextCursorMark=$nextCursorMark >> logs/log.txt
        [[ -e ${nextCursorMark} ]] && continue
        [[ "${nextCursorMark}" == "${cursorMark}" ]] && break
        cursorMark=${nextCursorMark}
        echo ${response} | grep -oE '"orderNo":"[0-9A-Za-z]*' | awk -F'"' '{print $4}' >> ${1}
        echo cursorMark assignment cursorMark=$cursorMark >> logs/log.txt
    done
}

rm -rf logs
mkdir logs

echo starting at: > logs/start.end.log
date >> logs/start.end.log

start_day=$(date -d "-150 days" "+%Y-%m-%d")
end_day=$(date -d "-149 days" "+%Y-%m-%d")

base_url=http://solrcloud.prod-wmt-uscentral.order-service-customer-fb-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_hist_prod
q="(orderDate%3A%5B${start_day}T00:00:00Z%20TO%20${end_day}T00:00:00Z%5D%20AND%20shipNodeType%3AMARKETPLACE)&sort=orderNo%20asc&fl=orderNo&rows=1000"
write_orders logs/mp.txt

q="(orderDate%3A%5B${start_day}T00:00:00Z%20TO%20${end_day}T00:00:00Z%5D)&sort=orderNo%20asc&fl=orderNo&rows=1000"
write_orders logs/all.txt

grep -Fxv -f logs/mp.txt logs/all.txt > logs/diff.txt

base_url_s_back=http://solrcloud.prod-wmt-uscentral.order-services-internal-fb-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
base_url_s_main=http://solrcloud.prod-wmt-uscentral.order-services-internal-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
base_url_c_back=http://solrcloud.prod-cdc.order-services-primary-ha-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
base_url_c_main=http://solrcloud.prod-cdc.order-services-primary-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
base_url_n_back=http://solrcloud.prod-ndc.order-services-primary-ha-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
base_url_n_main=http://solrcloud.prod-ndc.order-services-primary-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new

start_s_back="curl -s -X POST -H 'Content-Type: application/json' '${base_url_s_back}/update' -d '{"
start_s_main="curl -s -X POST -H 'Content-Type: application/json' '${base_url_s_main}/update' -d '{"
start_c_back="curl -s -X POST -H 'Content-Type: application/json' '${base_url_c_back}/update' -d '{"
start_c_main="curl -s -X POST -H 'Content-Type: application/json' '${base_url_c_main}/update' -d '{"
start_n_back="curl -s -X POST -H 'Content-Type: application/json' '${base_url_n_back}/update' -d '{"
start_n_main="curl -s -X POST -H 'Content-Type: application/json' '${base_url_n_main}/update' -d '{"

end="}'"

while read line
do
    eval ${start_s_back}'"delete":'$line${end} > /dev/null &
    eval ${start_s_main}'"delete":'$line${end} > /dev/null &
    eval ${start_c_back}'"delete":'$line${end} > /dev/null &
    eval ${start_c_main}'"delete":'$line${end} > /dev/null &
    eval ${start_n_back}'"delete":'$line${end} > /dev/null &
    eval ${start_n_main}'"delete":'$line${end} > /dev/null &
done < logs/diff.txt

echo ending at: >> logs/start.end.log
date >> logs/start.end.log

