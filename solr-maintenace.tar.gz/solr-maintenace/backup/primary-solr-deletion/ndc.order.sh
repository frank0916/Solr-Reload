base_url=http://solrcloud.prod-ndc.order-services-primary-ha-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
start=37MONTHS
end=6MONTHS
q="orderDate%3A%5BNOW-${start}%20TO%20NOW-${end}%5D&rows=1000&fl=idx&sort=orderDate%20asc"
part1="curl -s -X POST -H 'Content-Type: application/json' '${base_url}/update' -d '{"
part3="}'"
while true; do
    hour=`date +%H`
    [[ ${hour} -lt 6 || ${hour} -gt 12 ]] && sleep 1800 && continue
    part2=`curl -s "${base_url}/select?q=${q}" | sed -n 's/^ *"idx":"\([^"]*\).*/"delete":"\1"/p' | paste -sd "," -`
    [ -z "${part2}" ] || eval ${part1}${part2}${part3}
done
