cd /app/solr.deletion.by.date/

nohup ./deleteByDate.sh &


