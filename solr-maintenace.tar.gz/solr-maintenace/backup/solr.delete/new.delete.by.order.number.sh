urls=(
http://solrcloud.prod-az-southcentralus.order-services-primary2-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_prod_new
http://solrcloud.prod-az-southcentralus.order-services-primary2-dr-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_prod_new
http://solrcloud.prod-cdc.order-services-primary-ha-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
http://solrcloud.prod-cdc.order-services-primary-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
http://solrcloud.prod-ndc.order-services-primary-ha-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
http://solrcloud.prod-ndc.order-services-primary-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
http://solrcloud.prod-wmt-uscentral.order-services-internal-fb-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
http://solrcloud.prod-wmt-uscentral.order-services-internal-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
)

len=${#urls[@]}
echo "len=$len"
index=0
while true; do
  echo ${urls[$index]} #get order list
  for ((i=0; i<$len; i++)); do
    if [[ "$i" != "$index" ]]; then
        echo ${urls[$i]} & #delete order list from this solr in background
    fi 
  done
  echo ${urls[$index]} #delete order list in foreground
  index=$(( (index+1) % len ))
done
