base_url=http://solrcloud.prod-az-westus2.order-services-primary2-prod.ms-df-solrcloud.westus2.prod.us.walmart.net:8983/solr/orders_prod_new
#o_s=6MONTHS
o_s=180DAYS
t_s=3DAYS
q="(orderDate%3A%5B*%20TO%20NOW-${t_s}%5D%20AND%20isTestMode%3Atrue)%20OR%20orderDate%3A%5B*%20TO%20NOW-${o_s}%5D&rows=1000&fl=idx&sort=orderDate%20asc"
part1="curl -s -X POST -H 'Content-Type: application/json' '${base_url}/update' -d '{"
part3="}'"
while true; do
    part2=`curl -s "${base_url}/select?q=${q}" | sed -n 's/^ *"idx":"\([^"]*\).*/"delete":"\1"/p' | paste -sd "," -`
    [ -z "${part2}" ] || eval ${part1}${part2}${part3}
    sleep 1
done
