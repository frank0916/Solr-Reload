package com.walmart.scos.services.orders.biz;

import com.walmart.iris.services.producer.KafkaEventProducer;
import com.walmart.scos.services.orders.common.OrdersConsumerConfig;
import com.walmart.scos.services.orders.common.OrdersEvent;
import com.walmart.scos.services.orders.dao.CommonDao;
import com.walmart.scos.services.orders.dao.CommonDaoFactory;
import com.walmart.scos.services.orders.dao.CommonDaoImpl;
import com.walmart.scos.services.orders.model.CustOrderDO;
import com.walmart.scos.services.orders.model.OrderDO;
import com.walmart.scos.services.orders.model.QueryResult;
import com.walmart.scos.services.orders.utils.BaseConsumerSpringContextTests;
import com.walmart.scos.services.orders.utils.OSCompressionUtil;
import com.walmart.scos.services.orders.utils.OSConstants;
import com.walmart.scos.services.orders.utils.OSObjectMapper;
import com.walmart.services.order.common.model.Order;
import io.strati.StratiServiceProvider;
import io.strati.configuration.ConfigurationService;
import io.strati.txnmarking.Transaction;
import io.strati.txnmarking.TransactionMarkingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.testng.annotations.*;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Timestamp;
import java.time.ZonedDateTime;
import java.util.*;

import static com.google.common.util.concurrent.MoreExecutors.newDirectExecutorService;
import static com.walmart.scos.services.orders.biz.TestHelper.*;
import static com.walmart.scos.services.orders.utils.OSConstants.*;
import static com.walmart.scos.services.orders.utils.OSExecutorService.getExecutorService;
import static java.time.format.DateTimeFormatter.ISO_INSTANT;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;
import static org.testng.Assert.*;


@ContextConfiguration(locations = {
  "classpath:/META-INF/test-consumer-biz-context.xml"
})
@Test(singleThreaded = true)
public class ConsumeThenLookupTestBk extends BaseConsumerSpringContextTests {

    TimeZone localTimeZone;

    KafkaEventProducer<OrdersEvent<?>> kafkaEventProducer =
        mock(KafkaEventProducer.class);

    @Autowired
    ConsumerBizImpl consumerBiz;

    @Autowired
    LookupBizImpl lookupBiz;

    @Autowired
    ConfigurationService configurationService;

    @Autowired
    CommonDaoImpl commonDao;

    CommonDao daoSpy;
    CommonDaoFactory commonDaoFactory;
    ConsumerBizImpl consumerBizSpy;


    @BeforeClass
    void setup() {
        consumerBiz.kafkaEventProducer = kafkaEventProducer;
    }

    @BeforeMethod
    void start() {
        commonDaoFactory = consumerBiz.commonDaoFactory;
        consumerBizSpy = spy(consumerBiz);
        daoSpy = spy(commonDao);
        consumerBizSpy.commonDaoFactory = spy(commonDaoFactory);
        doAnswer(invocationOnMock -> daoSpy).
        when(consumerBizSpy.commonDaoFactory).getDao(any());
        consumerBiz.ordersConsumerConfig.setOS3enabled(false);
    }

    @AfterMethod
    void stop() {
        validateMockitoUsage();
        consumerBiz.commonDaoFactory = commonDaoFactory;
    }

    @BeforeSuite
    void setTimeZone() {
        localTimeZone = TimeZone.getDefault();
        TimeZone dataCenterTimeZone = TimeZone.getTimeZone("UTC");
        TimeZone.setDefault(dataCenterTimeZone);
        ConsumerBizImpl.executorService = newDirectExecutorService();
    }

    @AfterSuite
    void restoreTimeZone() {
        TimeZone.setDefault(localTimeZone);
        ConsumerBizImpl.executorService = getExecutorService();
    }

    @Test(description = "insert to Cassandra, secondary and primary Solr")
    public void testCassandraSolr() {
        List<String> orderNoList = new ArrayList<>();
        orderNoList.add(checkDaysBack(0));
        orderNoList.add(checkDaysBack(175));
        orderNoList.add(checkDaysBack(185));
        for (String orderNo : orderNoList) {
            checkLookup(orderNo);
        }
    }


    String checkDaysBack(int daysBack) {
        String orderNo = "checkDayBack" + daysBack;
        deleteOrderNo(orderNo);

        String file = "early-order-drop/1.oms.order.json";
        String payload = readFile(file);
        String orderDt = getValueByName(payload, ORDER_DATE);

        long currentTime = System.currentTimeMillis();
        long orderTime = currentTime - MILLIS_SECONDS_PER_DAY * daysBack;

        long orderTimeInPayload = getTime(orderDt);
        long adjust = orderTime - orderTimeInPayload;

        payload = replace(adjust, payload);
        String oldOrderNo = getValueByName(payload, ORDER_NO);
        payload = payload.replaceAll(oldOrderNo, orderNo);

        consumerBizSpy.insertOrder(payload, null);

        // verify C* and Solr writes
        verify(daoSpy, atLeast(1)).
          insertOrUpdateToCassandra(any(), any(), anyInt());
        verify(daoSpy, atLeast(1)).
          insertOrUpdateToSecSolr(any(), any(), any());
        verify(daoSpy, times(daysBack > 180 ? 0 : 1)).
            insertOrUpdateToSolr(any(), any(), any());
        verifyNoMoreInteractions(kafkaEventProducer);
        reset(consumerBizSpy);
        reset(daoSpy);

        return orderNo;
    }

    void checkLookup(String orderNo) {
        Map queryMap = createQueryMap(orderNo);
        boolean history = TRUE.equals(queryMap.remove(HISTORY));
        if (history)
            queryMap.put("associationType", "CAREPLAN");

        verifySolrRead(orderNo, history, queryMap);
    }

    Map<String, String> createQueryMap(String orderNo) {
        String orderStr = queryOrderNo(orderNo);
        String orderDt = getValueByName(orderStr, ORDER_DATE);
        // RFC 822 to ISO_ZONED_DATE_TIME format
        //yyyy-MM-dd'T'HH:mm:ss.SSS-hhmm to yyyy-MM-dd'T'HH:mm:ss.SSS-hh:mm
        orderDt = orderDt.substring(0, 26) + ':' + orderDt.substring(26);
        ZonedDateTime zdt = ZonedDateTime.parse(orderDt);

        Map<String, String> params = new HashMap<>();
        params.put(
            FROM_ORDER_DATE,
            ISO_INSTANT.format(zdt.minusNanos(10000000))
        );
        params.put(
            TO_ORDER_DATE,
            ISO_INSTANT.format(zdt.plusNanos(10000000))
        );

        long currentTime = System.currentTimeMillis();
        long orderTime = zdt.toInstant().getEpochSecond() * 1000;
        long daysInBetween = (currentTime - orderTime) / MILLIS_SECONDS_PER_DAY;
        boolean history = daysInBetween > 180;

        params.put(HISTORY, Boolean.toString(history));
        return params;
    }

    void verifySolrRead(
        String orderNo,
        boolean history,
        Map<String, String> queryParams
    ) {
        MultivaluedMap mvMap = new MultivaluedHashMap(queryParams);
        TransactionMarkingService TMS = StratiServiceProvider.getInstance().
            getTransactionMarkingService().get();
        Transaction top = TMS.topTransaction("category", "group").start();
        TMS.transaction(top, "ostestcategory", "ostestgroup").start();

        boolean found = false;
        int retry = 10;
        while (retry > 0) {
            retry--;
            QueryResult<Order> result =
                lookupBiz.getOrders(mvMap, "0", OSConstants.RESPONSE_GRP_FULL,
                    false,
                    history, // secondary for orderDate > 180, or primary
                    "", OSConstants.DISABLED_ENHANCED_PAGINATION, 0,
                    Order.class, OrderDO.class, CustOrderDO.class);

            assertNotNull(result);
            found = result.getData().stream().map(Order::getOrderNo).
                anyMatch(e -> orderNo.equals(e));
            if (found)
                break;
        }

        TMS.transaction(top, "ostestcategory", "ostestgroup").end();
        if (!found) {
            fail("Solr verification failed");
        }
    }

    void deleteOrderNo(String orderNo) {
        commonDao.queryCassandra(
          OrderDO.class,
          "delete from orderdata where order_no=?",
          orderNo);
    }

    String queryOrderNo(String orderNo) {
        List<OrderDO> orderDOList = commonDao.queryCassandra(
            OrderDO.class,
            "select * from orderdata where order_no=?",
            orderNo);

        assertNotNull(orderDOList);
        assertEquals(orderDOList.size(), 1);
        OrderDO orderDO = orderDOList.get(0);
        String orderPayload = OSCompressionUtil.decompress(
            orderDO.getCompressedData(),
            orderDO.getData(),
            orderNo);
        return orderPayload;
    }

    int insertOrder(ConsumerBizImpl consumer, String orderNo) {
        try {
            consumer.insertOrder(
                jsonStr(commonDao.findByCassandraKey(OrderDO.class, orderNo)),
                null
            );
            return 0; // succeed
        } catch (Exception e) {
            return 1; // failed
        }
    }

    int consume(ConsumerBizImpl consumer, Path path) throws Exception {
        return Files.lines(path). // each line contents one orderNo
            mapToInt(orderNo -> insertOrder(consumer, orderNo)).
            sum();
    }

    void reIndexSecondarySolr(boolean postAudit) throws Exception {
        String filePath = "order-numbers-to-index.txt";
        ConsumerBizImpl consumer = postAudit ? consumerBizSpy : consumerBiz;
        OrdersConsumerConfig cfg = consumerBiz.ordersConsumerConfig;
        boolean primarySolrEnable = cfg.getPrimarySolrEnabled();
        boolean cassandraWriteEnable = cfg.getCassandraWriteEnable();
        cfg.setPrimarySolrEnabled(false);
        cfg.setCassandraWriteEnable(false);

        Path file = getPath(filePath);
        int count = consume(consumer, file);

        cfg.setCassandraWriteEnable(cassandraWriteEnable);
        cfg.setPrimarySolrEnabled(primarySolrEnable);

        assertEquals(count, 0, "Total " + count + " orders failed to reload:");

        if (!postAudit) return;

        verifyNoMoreInteractions(kafkaEventProducer);
        verify(daoSpy, times(0)).
            insertOrUpdateToCassandra(any(), any(), anyInt());
        verify(daoSpy, atLeast(count)).
            insertOrUpdateToSecSolr(any(), any(), any());
    }

    // only verify for 2 orders to verify re-index logic
    // for small amount orders, reindex can be done by running testcase
    // inside IDE or with command line in terminal
    // mvn test -Dtest=ConsumeThenLookupTest#testReIndexSecSolrWithValidation
    @Test(description = "Re-index secondary Solr with validation")
    public void testReIndexSecSolrWithValidation() throws Exception {
        reIndexSecondarySolr(true);
    }

    // how to re-index the secondary Solr
    // replace the file content order-numbers-to-index.txt
    // mvn test -Dtest=ConsumeThenLookupTest#testReIndexSecSolr
    // optional adding -DfailIfNoTests=false to common line

    // note:
    // by default, this test case uses default setting for dev secondary Solr
    // for other clusters, follow file needs to be updated
    // biz/src/test/resources/META-INF/test-domain-us-bean.xml
    // to use the correct Cassandra and the secondary Solr settings
    @Test(description = "Re-index secondary Solr without validation")
    public void testReIndexSecSolr() throws Exception{
        reIndexSecondarySolr(false);
    }

    String jsonStr(OrderDO orderDO) {
        String data = orderDO.getData();
        if (data == null || data.isBlank()) {
            data = OSCompressionUtil.decompress(
                orderDO.getCompressedData(),
                null,
                orderDO.getOrderNo());
        }
        Order casOrder = OSObjectMapper.fromJSON(data, Order.class);
        OrdersEvent<Order> ordersEvent =
            new OrdersEvent<>();
        ordersEvent.setEventId(casOrder.getOrderNo());
        ordersEvent.setEventName(OSConstants.OS_ORDER_SNAPSHOT);
        ordersEvent.setEventSource(orderDO.getOrderSource());
        ordersEvent.setEventTime(
            new Timestamp(System.currentTimeMillis()));
        ordersEvent.setTenantId(orderDO.getTenantId());
        ordersEvent.setVerticalId(orderDO.getVerticalId());
        ordersEvent.setShardId(orderDO.getShardId());

        ordersEvent.setSrcCreatedDt(
            new Timestamp(orderDO.getSrcCreatedDt().getTime()));
        ordersEvent.setSrcModifiedDt(
            new Timestamp(orderDO.getSrcModifiedDt().getTime()));
        ordersEvent.setEventPayload(casOrder);

        return OSObjectMapper.toJSON(ordersEvent);
    }

    @Test(description = "conditionTypeCode Testing")
    public void testConditionTypeCode() {
        String orderCreated = readFile("file1");
        String poCreated = readFile("file2");

    }

}
