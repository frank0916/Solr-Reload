solr_url=http://solrcloud.prod-az-eastus2.order-services-primary2-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/purchase_orders

max_rows=300

get_orders()
{
  start=`date -d @${1:0:-3} +%Y-%m-%dT%H:%M:%S.${1: -3}Z`
  end=`date -d @${2:0:-3} +%Y-%m-%dT%H:%M:%S.${2: -3}Z`
  q="orderDate%3A%5B${start}%20TO%20${end}%5D"
  cnt=`curl -s --location -g --request GET "${solr_url}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
  if [[ $((cnt)) -eq 0 ]]; then
    :
  elif [[ $((cnt)) -le $((max_rows)) ]] || [[ $(($1))+1 -eq $(($2)) ]]; then
    curl -s --location -g --request GET "${solr_url}/select?q=${q}&fl=purchaseOrderNo&rows=${max_rows}" | \
    sed -n 's/^ *"purchaseOrderNo":"\([^"]*\).*/\1/p'
  else
    get_orders $(( ($1+$2)/2 )) $2
    get_orders $1 $(( ($1+$2)/2 ))
  fi
}


start_ts=1720396800000
end_ts=1721174400000

get_orders ${start_ts} ${end_ts}
