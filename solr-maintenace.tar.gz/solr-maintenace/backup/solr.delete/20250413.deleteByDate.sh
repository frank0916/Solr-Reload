function write_orders() {
    cursorMark=*
    while true; do
        response=`curl -s -X GET "$base_url/select?&q=$q&cursorMark=${cursorMark}"`
        #echo $response >> logs/log.txt
        nextCursorMark=$(echo "$response" | sed -n 's/.*"nextCursorMark":"\([^"]*\)".*/\1/p')
        #echo debug nextCursorMark=$nextCursorMark >> logs/log.txt
        [[ -e ${nextCursorMark} ]] && continue
        [[ "${nextCursorMark}" == "${cursorMark}" ]] && break
        cursorMark=${nextCursorMark}
        echo ${response} | grep -oE '"orderNo":"[0-9A-Za-z]*' | awk -F'"' '{print $4}' >> ${1}
        echo cursorMark assignment cursorMark=$cursorMark >> logs/log.txt
    done
}

rm -rf logs
mkdir logs

echo starting at: > logs/start.end.log
date >> logs/start.end.log

start_day=$(date -d "-154 days" "+%Y-%m-%d")
end_day=$(date -d "-153 days" "+%Y-%m-%d")

base_url=http://solrcloud.prod-wmt-uscentral.order-service-customer-fb-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_hist_prod
q="(orderDate%3A%5B${start_day}T00:00:00Z%20TO%20${end_day}T00:00:00Z%5D%20AND%20shipNodeType%3AMARKETPLACE)&sort=orderNo%20asc&fl=orderNo&rows=1000"
write_orders logs/mp.txt

q="(orderDate%3A%5B${start_day}T00:00:00Z%20TO%20${end_day}T00:00:00Z%5D)&sort=orderNo%20asc&fl=orderNo&rows=1000"
write_orders logs/all.txt

sort logs/mp.txt | uniq > logs/mp.u.txt
sort logs/all.txt | uniq > logs/all.u.txt

comm -23 logs/all.u.txt logs/mp.u.txt > logs/diff.txt

base_url_1=http://solrcloud.prod-wmt-uscentral.order-services-internal-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
base_url_2_main=http://solrcloud.prod-wmt-uscentral.order-services-internal-fb-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
base_url_3_back=http://solrcloud.prod-cdc.order-services-primary-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
base_url_4_main=http://solrcloud.prod-ndc.order-services-primary-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
base_url_5_back=http://solrcloud.prod-ndc.order-services-primary-ha-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
base_url_6_main=http://solrcloud.prod-cdc.order-services-primary-ha-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new


start_base_url_1="curl -s -X POST -H 'Content-Type: application/json' '${base_url_1}/update' -d '{"
start_base_url_2="curl -s -X POST -H 'Content-Type: application/json' '${base_url_2}/update' -d '{"
start_base_url_3="curl -s -X POST -H 'Content-Type: application/json' '${base_url_3}/update' -d '{"
start_base_url_4="curl -s -X POST -H 'Content-Type: application/json' '${base_url_4}/update' -d '{"
start_base_url_5="curl -s -X POST -H 'Content-Type: application/json' '${base_url_5}/update' -d '{"
start_base_url_6="curl -s -X POST -H 'Content-Type: application/json' '${base_url_6}/update' -d '{"


end="}'"

while read line
do
    eval ${start_base_url_1}'"delete":'$line${end} > /dev/null &
    eval ${start_base_url_2}'"delete":'$line${end} > /dev/null &
    eval ${start_base_url_3}'"delete":'$line${end} > /dev/null &
    eval ${start_base_url_4}'"delete":'$line${end} > /dev/null &
    eval ${start_base_url_5}'"delete":'$line${end} > /dev/null &
    eval ${start_base_url_6}'"delete":'$line${end} > /dev/null &
    eval ${start_sif}'"delete":'$line${end} > /dev/null &
done < logs/diff.txt

echo ending at: >> logs/start.end.log
date >> logs/start.end.log