function write_orders() {
    cursorMark=*
    while true; do
        response=`curl -s -X GET "$base_url/select?&q=$q&cursorMark=${cursorMark}"`
        #echo $response >> ${logdir}/log.txt
        nextCursorMark=$(echo "$response" | sed -n 's/.*"nextCursorMark":"\([^"]*\)".*/\1/p')
        #echo debug nextCursorMark=$nextCursorMark >> ${logdir}/log.txt
        [[ -e ${nextCursorMark} ]] && continue
        [[ "${nextCursorMark}" == "${cursorMark}" ]] && break
        cursorMark=${nextCursorMark}
        echo ${response} | grep -oE '"orderNo":"[0-9A-Za-z]*' | awk -F'"' '{print $4}' >> ${1}
        echo cursorMark assignment cursorMark=$cursorMark >> ${logdir}/log.txt
    done
}

logdir="${1}.${2}"

rm -rf ${logdir}
mkdir ${logdir}

echo starting at: > ${logdir}/start.end.log
date >> ${logdir}/start.end.log

base_url=http://solrcloud.prod-az-southcentralus.order-services-secondary-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_hist_prod
q="(orderDate%3A%5B${1}T00:00:00Z%20TO%20${2}T00:00:00Z%5D)&sort=orderNo%20asc&fl=orderNo&rows=1000"
write_orders ${logdir}/order-list.txt

echo ending at: >> ${logdir}/start.end.log
date >> ${logdir}/start.end.log