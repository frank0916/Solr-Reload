curl -s -X POST -H 'Content-Type: application/xml'\
 'http://solrcloud.prod-ndc.order-services-primary-ha-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/purchase_orders/update'\
 -d '<delete><query>purchaseOrderNo:111111</query></delete>'


curl -s -X POST -H 'Content-Type: application/xml'\
 'http://solrcloud.stg-az-southcentralus.order-services3-stg.ms-df-solrcloud.prod.us.walmart.net:8983/solr/return_orders_stg/update'\
 -d '<delete><query>returnOrderNo:_root_:134458538210056291</query></delete>'

curl -s -X POST -H 'Content-Type: application/xml'\
 'http://solrcloud.stg-az-southcentralus.order-services3-stg.ms-df-solrcloud.prod.us.walmart.net:8983/solr/return_orders_stg/update'\
 -d '<delete><query>idx:(_root_:134458729729640786 _root_:134458538210056291 _root_:134458638267271493 _root_:134458174306699538 _root_:134458257204314080 \
  _root_:134945259629524045 _root_:134945756981004378 _root_:134945432332410083 _root_:134945936972044612 _root_:134945754810541302)</query></delete>'


while read line
do
curl -s -X POST -H 'Content-Type: application/xml'\
 'http://solrcloud.stg-az-southcentralus.order-services3-stg.ms-df-solrcloud.prod.us.walmart.net:8983/solr/return_orders_teflon/update'\
 -d "<delete><query>returnOrderNo:${line}</query></delete>"
done << EOF
134458729729640786
134458538210056291
134458638267271493
134458174306699538
134458257204314080
134945259629524045
134945756981004378
134945432332410083
134945936972044612
134945754810541302
134458729729640786
134458538210056291
134458638267271493
134458174306699538
134458257204314080
134945259629524045
134945756981004378
134945432332410083
134945936972044612
134945754810541302
134945760337514713
134945409752760154
134945696856355208
134161448712618270
134945505636837786
134458793471219058
134458752678546757
134458900174568641
134458524711940600
134458006274848217
134458586540869750
134458137906450015
134458588616283571
134701753778459328
134910572058175546
134458729729640786
134458538210056291
134458638267271493
134458174306699538
134458257204314080
134945259629524045
134945756981004378
134945432332410083
134945936972044612
134945754810541302
134458729729640786
134458538210056291
134458638267271493
134458174306699538
134458257204314080
134945259629524045
134945756981004378
134945432332410083
134945936972044612
134945754810541302
134945760337514713
134945409752760154
134945696856355208
134161448712618270
134945505636837786
134458793471219058
134458752678546757
134458900174568641
134458524711940600
134458006274848217
134458586540869750
134458137906450015
134458588616283571
134701753778459328
134910572058175546
134458538210056291
134458638267271493
134458174306699538
134458257204314080
134945259629524045
134945756981004378
134945432332410083
134945936972044612
134945754810541302
134945760337514713
134945409752760154
134945696856355208
134161448712618270
134945505636837786
134458793471219058
134458752678546757
134458900174568641
134458524711940600
134458006274848217
134458586540869750
134458137906450015
134458588616283571
134910572058195546
134910572058185546
134910572058175546
134701753778459328
134458638267271493
134458174306699538
134458257204314080
134945259629524045
134945756981004378
134945432332410083
134945936972044612
134945754810541302
134945760337514713
134945409752760154
134945696856355208
134161448712618270
134945505636837786
134458793471219058
134458752678546757
134458900174568641
134458524711940600
134458006274848217
134458586540869750
134458137906450015
134458588616283571
134910572058195546
134910572058185546
134910572058175546
134701753778459328
EOF


while read line
do
curl -s -X POST -H 'Content-Type: application/xml'\
 'http://solrcloud.stg-az-southcentralus.order-services3-stg.ms-df-solrcloud.prod.us.walmart.net:8983/solr/returns_hist_teflon/update'\
 -d "<delete><query>returnOrderNo:$line</query></delete>"
done << EOF
134458538210056291
134458638267271493
134458174306699538
134458257204314080
134945259629524045
134945756981004378
134945432332410083
134945936972044612
134945754810541302
134945760337514713
134945409752760154
134945696856355208
134161448712618270
134945505636837786
134458793471219058
134458752678546757
134458900174568641
134458524711940600
134458006274848217
134458586540869750
134458137906450015
134458588616283571
134910572058195546
134910572058185546
134910572058175546
134701753778459328
134458638267271493
134458174306699538
134458257204314080
134945259629524045
134945756981004378
134945432332410083
134945936972044612
134945754810541302
134945760337514713
134945409752760154
134945696856355208
134161448712618270
134945505636837786
134458793471219058
134458752678546757
134458900174568641
134458524711940600
134458006274848217
134458586540869750
134458137906450015
134458588616283571
134910572058195546
134910572058185546
134910572058175546
134701753778459328
EOF


while read line
do
curl -s "http://solrcloud.stg-az-southcentralus.order-services3-stg.ms-df-solrcloud.prod.us.walmart.net:8983/solr/returns_hist_teflon/select?fl=returnOrderNo&q=returnOrderNo%3A${line}" | grep '"numFound":1'
done < return_order_number_list_reloading.txt | wc -l

while read line
do
curl -s "http://solrcloud.stg-az-southcentralus.order-services3-stg.ms-df-solrcloud.prod.us.walmart.net:8983/solr/return_orders_teflon/select?q=returnOrderNo%3A${line}" | grep '"numFound":1'
done < return_order_number_list_reloading.txt | wc -l



 curl -s -X POST -H 'Content-Type: application/xml'\
 'http://solrcloud.prod-wmt-useast.order-service-customer-prod.ms-df-solrcloud.prod.walmart.com/solr/orders_hist_prod/update'\
 -d '<delete><query>orderNo:100000000000040</query></delete>'

 curl -s -X POST -H 'Content-Type: application/xml'\
 'http://solrcloud.prod-wmt-uscentral.order-service-customer-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_hist_prod/update'\
 -d '<delete><query>orderNo:100000000000040</query></delete>'


http://solrcloud.prod-az-westus2.order-service-customer-az-prod.ms-df-solrcloud.westus2.prod.us.walmart.net
http://solrcloud.prod-wmt-uswest.order-service-customer-prod.ms-df-solrcloud.us-west2.us.walmart.net

curl -s -X POST -H 'Content-Type: application/xml'\
 'http://solrcloud.prod-wmt-uswest.order-service-customer-prod.ms-df-solrcloud.us-west2.us.walmart.net:8983/solr/orders_hist_prod/update'\
 -d '<delete><query>orderNo:100000000000050</query></delete>'



 curl -s -X POST -H 'Content-Type: application/xml'\
 'http://solrcloud.prod-wmt-uswest.order-service-customer-prod.ms-df-solrcloud.us-west2.us.walmart.net:8983/solr/orders_hist_prod/update'\
 -d '<delete><query>orderNo:${line}</query></delete>'

curl -s --location 'http://lookup-app.teflon.order-services.cp.prod.us.walmart.net/orders-lookup/services/v4/orders?customerId=56cd41ab-06f6-47ab-a6b7-8378e13962e4&USItemId=1218246358&fromOrderDate=NOW-60DAYS&toOrderDate=NOW&limit=300' \
--header 'WM_SVC.NAME: order-service' \
--header 'WM_SVC.ENV: stg' \
--header 'WM_SVC.VERSION: 4.0.0' \
--header 'WM_CONSUMER.ID: a7d088bd-53a9-4b1a-b039-4f055e2a90f9' \
--header 'WM_CONSUMER.TENANT_ID: 0' \
--header 'WM_QOS.CORRELATION_ID: $(uuidgen)' \
--header 'Content-Type: application/json' \
--header 'Accept: application/json' \
--header 'Accept-Language: es-US' | json_pp | grep '"orderNo"' | awk -F'"' '{print $4}' | sort | uniq
#delete orders in orders.txt
while read line
do
 curl -s -X POST -H 'Content-Type: application/xml'\
 'http://solrcloud.prod-wmt-uswest.order-service-customer-prod.ms-df-solrcloud.us-west2.us.walmart.net:8983/solr/orders_hist_prod/update'\
 -d "<delete><query>orderNo:${line}</query></delete>"

 curl -s -X POST -H 'Content-Type: application/xml'\
 'http://solrcloud.stg-az-southcentralus.order-services3-stg.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_teflon_hist/update'\
 -d "<delete><query>orderNo:${line}</query></delete>"
 done < orders.txt