base_url=http://solrcloud.prod-az-westus2.order-services-return-prod.ms-df-solrcloud.westus2.prod.us.walmart.net:8983/solr/return_orders
q="orderDate:[*%20TO%20NOW-12MONTHS]%20AND%20path:1.ReturnOrder&rows=400&fl=idx&sort=orderDate%20asc"
part1="curl -s -X POST -H 'Content-Type: application/xml' '${base_url}/update' -d '<delete><query>"
part3="</query></delete>'"
while true; do
    part2=`curl -s --location -g --request GET "${base_url}/select?q=${q}" | sed -n 's/^ *"idx":"\([1-9][0-9]*\)".*/_root_:\1/p' | paste -sd ' ' - | sed -e 's/ / OR /g'`
    [ -z "${part2}" ] || eval ${part1}${part2}${part3}
    sleep 120
done
