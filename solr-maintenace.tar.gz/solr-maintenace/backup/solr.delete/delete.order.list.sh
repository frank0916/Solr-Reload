count=0
echo start at: >> start.end.log
date >> start.end.log


base_url_s_back=http://solrcloud.prod-az-southcentralus.order-services-primary2-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_prod_new
base_url_s_main=http://solrcloud.prod-az-southcentralus.order-services-primary2-dr-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_prod_new
base_url_c_back=http://solrcloud.prod-cdc.order-services-primary-ha-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
base_url_c_main=http://solrcloud.prod-cdc.order-services-primary-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
base_url_n_back=http://solrcloud.prod-ndc.order-services-primary-ha-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
base_url_n_main=http://solrcloud.prod-ndc.order-services-primary-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
base_url_sif=http://solrcloud.prod-wmt-uscentral.order-services-internal-fb-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new

start_s_back="curl -s -X POST -H 'Content-Type: application/json' '${base_url_s_back}/update' -d '{"
start_s_main="curl -s -X POST -H 'Content-Type: application/json' '${base_url_s_main}/update' -d '{"
start_c_back="curl -s -X POST -H 'Content-Type: application/json' '${base_url_c_back}/update' -d '{"
start_c_main="curl -s -X POST -H 'Content-Type: application/json' '${base_url_c_main}/update' -d '{"
start_n_back="curl -s -X POST -H 'Content-Type: application/json' '${base_url_n_back}/update' -d '{"
start_n_main="curl -s -X POST -H 'Content-Type: application/json' '${base_url_n_main}/update' -d '{"
start_sif="curl -s -X POST -H 'Content-Type: application/json' '${base_url_sif}/update' -d '{"

end="}'"

while read line
do
eval ${start_s_main}'"delete":'$line${end} > /dev/null &
    eval ${start_s_back}'"delete":'$line${end} > /dev/null &
    eval ${start_c_main}'"delete":'$line${end} > /dev/null &
    eval ${start_c_back}'"delete":'$line${end} > /dev/null &
    eval ${start_n_main}'"delete":'$line${end} > /dev/null &
    eval ${start_n_back}'"delete":'$line${end} > /dev/null &
    eval ${start_sif}'"delete":'$line${end} > /dev/null &
    echo $line >> start.end.log
    ((count++))
done < order-list.txt >> start.end.log
echo total order deleted ${count}
echo ending at: >> start.end.log
date >> start.end.log
