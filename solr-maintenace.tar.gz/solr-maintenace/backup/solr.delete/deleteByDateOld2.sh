function write_orders() {
    cursorMark=*
    while true; do
        response=`curl -s -X GET "$base_url/select?&q=$q&cursorMark=${cursorMark}"`
        #echo $response >> logs/log.txt
        nextCursorMark=$(echo "$response" | sed -n 's/.*"nextCursorMark":"\([^"]*\)".*/\1/p')
        #echo debug nextCursorMark=$nextCursorMark >> logs/log.txt
        [[ -e ${nextCursorMark} ]] && continue
        [[ "${nextCursorMark}" == "${cursorMark}" ]] && break
        cursorMark=${nextCursorMark}
        echo ${response} | grep -o -P '(?<="orderNo":")[^"]+(?=")' >> ${1}
        echo cursorMark assignment cursorMark=$cursorMark >> logs/log.txt
    done
}
rm -rf logs
mkdir logs

echo starting at: > logs/start.end.log
date >> logs/start.end.log

start_day=$(date -d "-167 days" "+%Y-%m-%d")
end_day=$(date -d "-166 days" "+%Y-%m-%d")

base_url=http://solrcloud.prod-az-southcentralus.order-services-secondary-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_hist_prod
q="(orderDate%3A%5B${start_day}T00:00:00Z%20TO%20${end_day}T00:00:00Z%5D%20AND%20shipNodeType%3AMARKETPLACE)&sort=orderNo%20asc&fl=orderNo&rows=1000"
write_orders logs/mp.txt
q="(orderDate%3A%5B${start_day}T00:00:00Z%20TO%20${end_day}T00:00:00Z%5D)&sort=orderNo%20asc&fl=orderNo&rows=1000"
write_orders logs/all.txt
grep -Fxv -f logs/mp.txt logs/all.txt > logs/diff.txt
base_url_sc=http://solrcloud.prod-az-southcentralus.order-services-primary2-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_prod_new
base_url_w2=http://solrcloud.prod-az-westus2.order-services-primary2-prod.ms-df-solrcloud.westus2.prod.us.walmart.net:8983/solr/orders_prod_new
start_sc="curl -s -X POST -H 'Content-Type: application/json' '${base_url_sc}/update' -d '{"
start_w2="curl -s -X POST -H 'Content-Type: application/json' '${base_url_w2}/update' -d '{"
end="}'"
count=0
while read line
do
    eval ${start_sc}'"delete":'$line${end} > /dev/null &
    eval ${start_w2}'"delete":'$line${end} > /dev/null &
    let count=$count+1
    [[ "$(($count % 1000))" == "0" ]] && sleep 1
done < logs/diff.txt

echo ending at: >> logs/start.end.log
date >> logs/start.end.log


