urls=(
http://solrcloud.prod-az-southcentralus.order-services-primary2-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_prod_new
http://solrcloud.prod-az-southcentralus.order-services-primary2-dr-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_prod_new
http://solrcloud.prod-cdc.order-services-primary-ha-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
http://solrcloud.prod-cdc.order-services-primary-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
http://solrcloud.prod-ndc.order-services-primary-ha-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
http://solrcloud.prod-ndc.order-services-primary-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
http://solrcloud.prod-wmt-uscentral.order-services-internal-fb-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
http://solrcloud.prod-wmt-uscentral.order-services-internal-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new
)

q="orderDate%3A%5B2024-10-17T00%3A00%3A00Z%20TO%202024-10-18T00%3A00%3A00Z%5D&rows=0"
for i in ${urls}
do
  curl -s "$i/select?q=${q}" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'
done
