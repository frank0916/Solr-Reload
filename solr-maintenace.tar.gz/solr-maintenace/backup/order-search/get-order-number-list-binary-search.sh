#!/bin/bash
# input - this script takes 2 parameter
# $1 start date-time in the format of yyyy-MM-ddThh:mm:ssZ
# $2 end date-time in the format of yyyy-MM-ddThh:mm:ssZ
# output - orderNo in stdout

max_rows=300

get_orders()
{
  start=`date -d @${1:0:-3} +%Y-%m-%dT%H:%M:%S.${1: -3}Z`
  end=`date -d @${2:0:-3} +%Y-%m-%dT%H:%M:%S.${2: -3}Z`
  #echo start=$start, end=$end
  q="orderDate%3A%5B${start}%20TO%20${end}%5D"
  # echo url="${solr_url}/select?q=${q}&rows=0"
  cnt=`curl -s --location -g --request GET "${solr_url}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
  if [[ $cnt -eq 0 ]]; then
    #echo 0: cnt=$cnt, start=$start, end=$end
    :
  elif [ $cnt -le $max_rows ] || [ $(( $1 + 1 )) -eq $2 ]; then
    #echo "${max_rows}-": cnt=$cnt, start=$start, end=$end
    curl -s --location -g --request GET "${solr_url}/select?q=${q}&fl=orderNo&rows=${max_rows}" | \
    sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p'
  else
    #echo "1000+": cnt=$cnt, start=$start, end=$end
    get_orders $(( ($1+$2)/2 )) $2
    get_orders $1 $(( ($1+$2)/2 ))
  fi
}

solr_url=http://solrcloud.prod-wmt-uswest.order-service-customer-fb-prod.ms-df-solrcloud.us-west2.us.walmart.net:8983/solr/orders_hist_prod

start_second=$(date -d "$1" +%s)
end_second=$(date -d "$2" +%s)

get_orders ${start_second}000 ${end_second}000

