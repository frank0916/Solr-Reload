start=2022-05-08
end=2025-05-08
while ! [[ $start > $end ]]; do
    next=$(date -d "$start + 1 day" +%F)
    echo ${start}T00:00:00Z ${next}T00:00:00Z
    start=$next
done
