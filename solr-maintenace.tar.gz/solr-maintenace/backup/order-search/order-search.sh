function write_orders() {
    cursorMark=*
    while true; do
        response=`curl -s -X GET "$base_url/select?&q=$q&cursorMark=${cursorMark}"`
        #echo $response >> logs/log.txt
        nextCursorMark=$(echo "$response" | sed -n 's/.*"nextCursorMark":"\([^"]*\)".*/\1/p')
        #echo debug nextCursorMark=$nextCursorMark >> logs/log.txt
        [[ -e ${nextCursorMark} ]] && continue
        [[ "${nextCursorMark}" == "${cursorMark}" ]] && break
        cursorMark=${nextCursorMark}
        echo ${response} | grep -oE '"orderNo":"[0-9A-Za-z]*' | awk -F'"' '{print $4}' >> ${1}
        #echo cursorMark assignment cursorMark=$cursorMark
    done
}

start_day=2025-01-01
end_day=2025-02-26

base_url=http://solrcloud.prod-az-southcentralus.order-services-secondary-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_hist_prod
q="conditionTypeCode%3A0%20AND%20orderDate%3A%5BNOW-60DAYS%20TO%20NOW%5D&sort=orderNo%20asc&fl=orderNo&rows=1000"
write_orders orders.txt



#http://solrcloud.prod-az-southcentralus.order-services-secondary-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_hist_prod/select?cursorMark=*&q=conditionTypeCode%3A0%20AND%20orderDate%3A%5BNOW-60DAYS%20TO%20NOW%5D&sort=orderNo%20asc