#!/bin/bash

function write_orders() {
    cursorMark=*
    while true; do
        response=`curl -s -X GET "$base_url/select?&q=$q&cursorMark=${cursorMark}"`
        # echo $response >> ${logdir}/log.txt
        nextCursorMark=$(echo "$response" | sed -n 's/.*"nextCursorMark":"\([^"]*\)".*/\1/p')
        # echo debug nextCursorMark=$nextCursorMark >> ${logdir}/log.txt
        [[ -e ${nextCursorMark} ]] && continue
        [[ "${nextCursorMark}" == "${cursorMark}" ]] && break
        cursorMark=${nextCursorMark}
        echo ${response} | grep -oE '"orderNo":"[0-9A-Za-z]*' | awk -F'"' '{print $4}' >> ${1}
        # echo cursorMark assignment cursorMark=$cursorMark >> ${logdir}/log.txt
    done
}

logdir="${1}.${2}"

rm -rf ${logdir}
mkdir ${logdir}

echo starting at: > ${logdir}/start.end.log
date >> ${logdir}/start.end.log

#use fb cluster instead
base_url=http://solrcloud.prod-wmt-uscentral.order-service-customer-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_hist_prod
q="(orderDate%3A%5B${1}%20TO%20${2}%5D)&sort=orderNo%20asc&fl=orderNo&rows=1000"
write_orders ${logdir}/order-list.txt

echo ending at: >> ${logdir}/start.end.log
date >> ${logdir}/start.end.log

#example usage: ./get-order-number-list-in-ts-range.sh 2024-01-01T00:00:00Z 2024-01-31T23:59:59Z
#hot to create date list
#for i in {1..181}; do date -v-"$i"d +%Y-%m-%dT00:00:00Z; done > 1.txt
#for i in {0..180}; do date -v-"$i"d +%Y-%m-%dT00:00:00Z; done > 2.txt
#paste -d' ' 1.txt 2.txt > 3.txt
#echo 3>pause.txt
#while read line; do ./get-order-number-list-in-ts-range.sh ${line};sleep $(cat pause.txt); done < 3.txt

#how to read a number from a file and sleep for that many seconds
#sleep $(cat pause.txt)


#while read line; do ./get-order-number-list-in-ts-range-debugsh ${line}; done < 3.txt