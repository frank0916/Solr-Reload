#!/bin/bash

function write_orders() {
    cursorMark=*
    while true; do
        response=`curl -s -X GET "$base_url/select?&q=$q&cursorMark=${cursorMark}"`
        nextCursorMark=$(echo "$response" | sed -n 's/.*"nextCursorMark":"\([^"]*\)".*/\1/p')
        [[ -e ${nextCursorMark} ]] && continue
        [[ "${nextCursorMark}" == "${cursorMark}" ]] && break
        cursorMark=${nextCursorMark}
        echo ${response} | grep -oE '"orderNo":"[0-9A-Za-z]*' | awk -F'"' '{print $4}' >> ${1}
    done
}

#use fb cluster instead
base_url=http://solrcloud.prod-wmt-uscentral.order-service-customer-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_hist_prod
q="(orderDate%3A%5B${1}%20TO%20${2}%5D)&sort=orderNo%20asc&fl=orderNo&rows=1000"
write_orders order-list.${logdir}.txt

#example usage: ./get-order-number-list-in-ts-range.sh 2024-01-01T00:00:00Z 2024-01-31T23:59:59Z
#how to create date list macOS
#for i in {1..181}; do date -v-"$i"d +%Y-%m-%dT00:00:00Z; done > 1.txt
#for i in {0..180}; do date -v-"$i"d +%Y-%m-%dT00:00:00Z; done > 2.txt
#how to create date list Linux
for i in {1..181}; do date --date="${i} days ago" +%Y-%m-%dT00:00:00Z; done > 1.txt
for i in {0..180}; do date --date="${i} days ago" +%Y-%m-%dT00:00:00Z; done > 2.txt

paste -d' ' 1.txt 2.txt > 3.txt
#echo 3>pause.txt
#while read line; do ./get-order-number-list-in-ts-range.sh ${line};sleep $(cat pause.txt); done < 3.txt

#how to read a number from a file and sleep for that many seconds
#sleep $(cat pause.txt)


while read line; do ./get-order-number-list-in-ts-range.sh ${line}; done < 3.txt
