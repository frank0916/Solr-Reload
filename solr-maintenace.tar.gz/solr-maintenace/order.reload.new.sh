to_json() {
  while read order_no
  do
    echo '{event_id:"'$order_no'",event_name:"RELOAD_ORDERS",event_source:"OMSNEXT"}'
  done
}

solr_url=http://solrcloud.prod-az-southcentralus.order-services-secondary-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_hist_prod

get_orders()
{
  start=`date -d @${1:0:-3} +%Y-%m-%dT%H:%M:%S.${1: -3}Z`
  end=`date -d @${2:0:-3} +%Y-%m-%dT%H:%M:%S.${2: -3}Z`
  q="orderDate%3A%5B${start}%20TO%20${end}%5D"
  cnt=`curl -s --location -g --request GET "${solr_url}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
  if [[ $((cnt)) -eq 0 ]]; then
    :
  elif [[ $((cnt)) -le 1000 ]]; then
    curl -s --location -g --request GET "${solr_url}/select?q=${q}&fl=orderNo&rows=1000" | \
    sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p'
  elif [[ $(($1))+1 -ge $(($2)) ]]; then
    let loops=$cnt/1000
    while [ $loops -ge 0 ]
    do
      let offset=$loops*1000
      curl -s --location -g --request GET "${solr_url}/select?q=${q}&fl=orderNo&rows=1000&offset=${offset}" | \
      sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p'
      let loops=$loops-1
    done
  else
    get_orders $(( ($1+$2)/2 )) $2
    get_orders $1 $(( ($1+$2)/2 ))
  fi
}

get_orders $1 $2 | to_json | \
bin/kafka-console-producer.sh \
  --topic data-load-order-us \
  --bootstrap-server kafka-1173818850-1-1245094171.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-2-1245094174.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-3-1245094177.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-4-1245094180.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-5-1245094183.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-6-1245094186.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-7-1245094189.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-8-1245094192.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-9-1245094195.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-10-1245094198.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-11-1245094201.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-12-1245094204.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-13-1245094207.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-14-1245094210.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-15-1245094213.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092

