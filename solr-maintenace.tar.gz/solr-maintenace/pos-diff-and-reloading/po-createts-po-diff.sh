#! /bin/bash

# this script takes 2 parameters of timestamp
# $1 start time in milli seconds 2024-12-11T00:00:00Z
# $2 end time in milli seconds 2025-06-09T00:00:00Z

solr_url_1=http://solrcloud.prod-cdc.order-services-primary-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/purchase_orders
solr_url_2=http://solrcloud.prod-wmt-uscentral.order-services-internal-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/purchase_orders

max_rows=300

sync_po_in_ms_range()
{
  start=`date -d @${1:0:-3} +%Y-%m-%dT%H:%M:%S.${1: -3}Z`
  end=`date -d @${2:0:-3} +%Y-%m-%dT%H:%M:%S.${2: -3}Z`

  q="poCreatets%3A%5B${start}%20TO%20${end}%5D"

#   echo curl -s --request GET "'${solr_url_1}/select?q=${q}&rows=0'"
#   echo curl -s --request GET "'${solr_url_2}/select?q=${q}&rows=0'"

  cnt_1=`curl -s --location -g --request GET "${solr_url_1}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
  cnt_2=`curl -s --location -g --request GET "${solr_url_2}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`

#   echo counts $cnt_1, $cnt_2

  if [[ $((cnt_1)) -eq $((cnt_2)) ]]; then
    :
  elif [[ $cnt_1 -lt $max_rows ]] && [[ $cnt_2 -lt $max_rows ]] || [[ $(($1))+1 -eq $(($2)) ]]; then
    curl -s --location -g --request GET "${solr_url_1}/select?q=${q}&fl=purchaseOrderNo&rows=${max_rows}" | \
      sed -n 's/^ *"purchaseOrderNo":"\([^"]*\).*/\1/p' > purchase.1.txt
    curl -s --location -g --request GET "${solr_url_2}/select?q=${q}&fl=purchaseOrderNo&rows=${max_rows}" | \
      sed -n 's/^ *"purchaseOrderNo":"\([^"]*\).*/\1/p' > purchase.2.txt
    sort purchase.1.txt | uniq > purchase.1.u.txt
    sort purchase.2.txt | uniq > purchase.2.u.txt
    comm -3 purchase.1.u.txt purchase.2.u.txt | awk '{print $1}'
  else
    sync_po_in_ms_range $(( ($1+$2)/2 )) $2
    sync_po_in_ms_range $1 $(( ($1+$2)/2 ))
  fi
}

start_second=$(date -d "$1" +%s)
end_second=$(date -d "$2" +%s)

sync_po_in_ms_range ${start_second}000 ${end_second}000
