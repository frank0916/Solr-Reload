#!/bin/bash

auth_headers=( `curl -s --location 'https://sr-validation.stage.walmart.com/getAuth?env=prod' | awk 'NR > 1 {print $2}'` )

while read line
do
curl -s --location 'http://os-cus2-solr-mcw-consumer-app.prod.walmart.com/orders-consumer/services/v4/reload/order' \
--header 'Accept: application/json' \
--header 'Content-Type: application/json' \
--header 'WM_QOS.CORRELATION_ID: 2323' \
--header 'WM_SVC.VERSION: 1.0.0' \
--header 'WM_SVC.ENV: prod446' \
--header 'WM_SVC.NAME: ORDER-SERVICE' \
--header 'WM_CONSUMER.ID: 62a55923-8447-4205-b2f9-d712b35d8b27' \
--header 'WM_CONSUMER.TENANT_ID: 0' \
--header "wm_consumer.intimestamp: ${auth_headers[0]}" \
--header "wm_sec.auth_signature: ${auth_headers[1]}" \
--data '{"payload": {"event_id": "'$line'","event_name": "RELOAD_ORDERS","event_source": "OMSNEXT"}}'
done
