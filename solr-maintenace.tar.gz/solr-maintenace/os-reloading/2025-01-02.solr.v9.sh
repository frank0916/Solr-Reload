#export JAVA_HOME=$HOME/
export PATH=$JAVA_HOME/bin:$PATH

while read line
do
echo '{"event_id":"'$line'","event_name":"RELOAD_ORDERS","event_source":"OMSNEXT"}'
done < orders.txt | ./kafka-console-producer.sh --topic dca-data-reload --bootstrap-server kafka-1048092748-2-1325423757.scus.kafka-v2-shared4-stg.ms-df-messaging.stg-az-southcentralus-9.prod.us.walmart.net:9092,kafka-1048092748-1-1325423754.scus.kafka-v2-shared4-stg.ms-df-messaging.stg-az-southcentralus-9.prod.us.walmart.net:9092,kafka-1048092748-3-1325423760.scus.kafka-v2-shared4-stg.ms-df-messaging.stg-az-southcentralus-9.prod.us.walmart.net:9092

# publish order reload message to Kafka
# instruction
# appache download link:  https://kafka.apache.org/downloads
# wget https://archive.apache.org/dist/kafka/3.6.1/kafka_2.13-3.6.1.tgz
# 1. downlad Kafka 3.6.1 Scala 2.13 tar
# 2. run command to untar the file: tar zxf kafka_2.1.3-361.tgz
# 3. copy this file to bin directory: kafka_2.13-3.6.1/bin
# 4. make this file executable: chmod +x 2025-01-02.sh
# 5. copy order numbers into orders.txt file, one order number per line.
# 6. run command to publish messages to Kafka cluster: nohup ./2025-01-02.sh &
