import argparse
import collections
from enum import Enum
import requests
import sys
import time
from concurrent.futures import ThreadPoolExecutor

url = 'orders-consumer-stage.reload-orders-consumer.k8s.glb.us.walmart.net/orders-consumer/services/v4/reload/order'

headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'WM_QOS.CORRELATION_ID': '2323',
    'WM_SVC.VERSION': '1.0.0',
    'WM_SVC.ENV': 'prod405',
    'WM_SVC.NAME': 'ORDER-SERVICE',
    'WM_CONSUMER.ID': '62a55923-8447-4205-b2f9-d712b35d8b27',
    'WM_CONSUMER.TENANT_ID': '0'
}


class Status(Enum):
    waiting = 0
    reloaded = 1
    failed = 2
    exception = 3


def reload_order_no(order_no):
    payload = '{"payload":{"event_id":"'f"{order_no}"'", "event_name": "RELOAD_ORDERS", "event_source": "OMSNEXT"}}'
    return requests.request(
        "POST",
        url,
        headers=headers,
        data=payload,
        timeout=20)


class OrderReload:
    threads = 1

    def __init__(self, threads):
        self.threads = threads
        self.queue = collections.deque()
        self.executor = ThreadPoolExecutor(max_workers=threads)

    @staticmethod
    def http(reload_status):
        try:
            response = reload_order_no(reload_status[0])
            if '{"status":"OK"}' == response.text:
                reload_status[1] = Status.reloaded
            else:
                reload_status[1] = Status.failed

        except:  # noqa
            reload_status[1] = Status.exception

    def append(self, order_no):
        reload_status = [order_no, Status.waiting]
        self.queue.append(reload_status)
        self.executor.submit(self.http, reload_status)

    def pop(self):
        length = len(self.queue)
        while length > 0:
            order_no_status = self.queue[0]

            if order_no_status[1] == Status.waiting:
                if length < self.threads:
                    return
                else:
                    time.sleep(0.005)
                    continue
            else:
                order_no_status = self.queue.popleft()
                print(order_no_status[0], "->", order_no_status[1].name)
                length -= 1

    def process(self):
        line = sys.stdin.readline()
        while line:
            self.append(line.strip())
            self.pop()
            line = sys.stdin.readline()

        self.executor.shutdown()

        while len(self.queue) > 0:
            self.pop()
            time.sleep(0.005)


def main():
    parser = argparse.ArgumentParser(
        description='Solr Order reload by reading orderNo from stdin'
    )
    parser.add_argument(
        '-t', '--threads', type=int, default=100, choices=range(1, 501),
        metavar='THREADS',
        help="number of threads from 1 to 100, default 10"
    )
    args = parser.parse_args()

    reload = OrderReload(args.threads)
    reload.process()


if __name__ == '__main__':
    main()

