start_date=2024-01-01
i=0
while [[ $i -lt 180 ]];
do
  start=`date -d "$start_date + $i day" +%Y-%m-%d`
  ((i++));
  end=`date -d "$start_date + $i day" +%Y-%m-%d`
  echo $start $end
done
