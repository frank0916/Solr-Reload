#!/bin/bash

url_1=http://solrcloud.prod-wmt-uscentral.order-service-customer-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_hist_prod
url_2=http://solrcloud.prod-wmt-uswest.order-service-customer-prod.ms-df-solrcloud.us-west2.us.walmart.net:8983/solr/orders_hist_prod

file_1=1
file_2=2

max_rows=1000

get_count() {
  start=`date -d @${1:0:-3} +%Y-%m-%dT%H:%M:%S.${1: -3}Z`
  end=`date -d @${2:0:-3} +%Y-%m-%dT%H:%M:%S.${2: -3}Z`
  #q="path%3A1.Order%20AND%20orderDate%3A%5B${start}%20TO%20${end}%5D"
  q="orderDate%3A%5B${start}%20TO%20${end}%5D"
  cnt=`curl -s --location -g --request GET "${3}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
}

get_orders()
{
  #echo four variables $1, $2, $3, $4
  get_count $1 $2 $3
  if [[ $((cnt)) -eq 0 ]]; then
    :
  elif [[ $((cnt)) -le $((max_rows)) ]] || [[ $(($1+1)) -eq $(($2)) ]]; then
    if [[ "$3" == "$url_1" ]]; then
      cnt1=$cnt
      get_count $1 $2 $url_2
      [[ "$cnt" == "$cnt1" ]] && return;
    fi
    curl -s --location -g --request GET "${3}/select?q=${q}&fl=orderNo&rows=${max_rows}" | \
       sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p' >> "${4}"
    # [[ "$3" == "$url_1" ]] && echo get_orders $1 $2 $url_2 $file_2 >> debug.txt
    [[ "$3" == "$url_1" ]] && get_orders $1 $2 $url_2 $file_2
  else
    get_orders $(( ($1+$2)/2 )) $2 $3 $4
    get_orders $1 $(( ($1+$2)/2 )) $3 $4
  fi
}

end_ts=$(date +%s) #seconds of current epoch time
end_ts=$(($end_ts / 86400 * 86400000)) #convert to milli second of staring of today
days_to_sync=7
days=0

while [ $days -lt $days_to_sync ];
do
    start_ts=$(( end_ts - 86400000 ))
    get_count $start_ts $end_ts $url_1
    cnt1=$cnt

    get_count $start_ts $end_ts $url_2

    echo $start_ts $end_ts $cnt1 $cnt >> debug.txt

    if [[ $(( cnt1 - cnt)) -ge 0 ]]; then
        file_1="1.${start_ts}.${end_ts}.${cnt1}.txt"
        file_2="2.${start_ts}.${end_ts}.${cnt}.txt"

        echo file_1 $file_1, file_2 $file_2 >> debug.txt
 
        >"${file_1}"
        >"${file_2}"
 
        echo get_orders $start_ts $end_ts $url_1 $file_1 $file_2 >> debug.txt
        get_orders $start_ts $end_ts $url_1 $file_1 $file_2 # $file_2 can be removed

        sort $file_1 | uniq > "u.${file_1}"
        sort $file_2 | uniq > "u.${file_2}"
        comm -23 u.${file_1} u.${file_2} > "diff.$start_ts.$end_ts.txt"
        python3 order-reload.py < "diff.$start_ts.$end_ts.txt" > "out.$start_ts.$end_ts.txt"
    fi
    end_ts=$start_ts
    days=$(( $days + 1 ))
done

