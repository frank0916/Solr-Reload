export KAFKA_HOME=$HOME/kafka_2.13-3.6.1
export PATH=$JAVA_HOME/bin:$KAFKA_HOME/bin:$PATH

while read line
do
echo $line:'{"event_id":"'$line'","event_name":"RELOAD_ORDERS","event_source":"OMSNEXT"}'
done | kafka-console-producer.sh \
 --property "parse.key=true" \
 --property "key.separator=:" \
 --producer.config ./prod.kafka.properties \
 --topic us-orders-internal \
 --bootstrap-server kafka.kafka-v2-oms-order-sox-prod.wus2.westus2.prod.us.walmart.net:9093

# publish order reload message to Kafka
# instruction
# https://www.instaclustr.com/support/documentation/kafka/using-kafka/configure-keystore-to-use-mtls-authentication-with-clients/
# appache download link:  https://kafka.apache.org/downloads
# wget https://archive.apache.org/dist/kafka/3.6.1/kafka_2.13-3.6.1.tgz
# 1. downlad Kafka 3.6.1 Scala 2.13 tar
# 2. run command to untar the file: tar zxf kafka_2.1.3-361.tgz
# 3. copy this file to bin directory: kafka_2.13-3.6.1/bin
# 4. make this file executable: chmod +x 2025-01-02.sh
# 5. copy order numbers into orders.txt file, one order number per line.
# 6. run command to publish messages to Kafka cluster: nohup ./2025-01-02.sh &
