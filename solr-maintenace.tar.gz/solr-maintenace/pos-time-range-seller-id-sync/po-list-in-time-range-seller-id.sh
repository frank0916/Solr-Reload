#! /bin/bash

# this script takes 2 parameter of milliseconds
# $1 start time in the format of yyyy-MM-ddTHH:mm:ssZ, sample date 2025-04-01T00:00:00Z
# $2 end time in the format of yyyy-MM-ddTHH:mm:ssZ, sample date 2025-04-01T00:00:00Z
# $3 sellerId
# output - purchaseOrderNo in range to start and end timestamp will printed in purchase.no.list.txt

solr_url_1=http://solrcloud.prod-wmt-uscentral.order-services-internal-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/purchase_orders

max_rows=300

>purchase.no.list.txt

get_po_in_ms_range()
{
  start=`date -d @${1:0:-3} +%Y-%m-%dT%H:%M:%S.${1: -3}Z`
  end=`date -d @${2:0:-3} +%Y-%m-%dT%H:%M:%S.${2: -3}Z`

  #echo timestamps $start, $end

  q="orderDate%3A%5B${start}%20TO%20${end}%5D%20AND%20isTestPO%3Afalse%20AND%20poLineStatusInfoSellerId%3A%20${sellerId}"

  #echo curl -s --location -g --request GET "${solr_url_1}/select?q=${q}&rows=0"
  #echo curl -s --location -g --request GET "${solr_url_2}/select?q=${q}&rows=0"

  cnt_1=`curl -s --location -g --request GET "${solr_url_1}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`

  #echo counts $cnt_1, $cnt_2, $3

  if [[ $cnt_1 -lt $max_rows ]] && [[ $cnt_2 -lt $max_rows ]] || [[ $(($1))+1 -eq $(($2)) ]]; then
	  echo no-split $start $end
    curl -s --location -g --request GET "${solr_url_1}/select?q=${q}&fl=purchaseOrderNo&rows=${max_rows}" | \
      sed -n 's/^ *"purchaseOrderNo":"\([^"]*\).*/\1/p' >> purchase.no.list.txt
  else
	  echo split $start $end
    get_po_in_ms_range $(( ($1+$2)/2 )) $2
    get_po_in_ms_range $1 $(( ($1+$2)/2 ))
  fi
}

start_second=$(date -d "$1" +%s)
end_second=$(date -d "$2" +%s)
sellerId="$3"

#echo get_po_in_ms_range ${start_second}000 ${end_second}000 ${sellerId}
get_po_in_ms_range ${start_second}000 ${end_second}000 ${sellerId}

