#! /bin/bash

#ingest po_no from stdin
while read po_no
do
    curl -s --location "http://fms-event-service.prod.walmart.com/app/v2/reconciliation/po-all-events?purchaseOrderNumber=${po_no}" \
--header 'WM_CONSUMER.ID: 1000'
done

