@!/bin/bash
### Usage
### RemoteExecutionCommand.sh id.txt msin20 "ps -ef | grep -i PaymentCapureInServer"
###
echo '' > ./myscript1.out
for ip in $cat $1) ; do
echo IP $$ip} Command ${3} >> .myscript1.out
ssh -o BatchMode=yes -o StrictHostKeyChecking=no -i ~Manoj_data/t_oa -l $2} ${ip} "${3}" | grep -v "${3} | grep -v grep >> ./myscript1.out
done
