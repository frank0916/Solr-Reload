solr_url=http://solrcloud.stg-az-southcentralus.order-services3-stg.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_stg
max_rows=300
#macos version
get_orders()
{
  start=`date -r ${1:0:-3} "+%Y-%m-%dT%H:%M:%S.${1: -3}Z"`
  end=`date -r ${2:0:-3} "+%Y-%m-%dT%H:%M:%S.${2: -3}Z"`
  q="path%3A1.Order%20AND%20orderDate%3A%5B${start}%20TO%20${end}%5D"
  cnt=`curl -s --location -g --request GET "${solr_url}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
  if [[ $((cnt)) -eq 0 ]]; then
    :
  elif [[ $((cnt)) -le $((max_rows)) ]] || [[ $(($1))+1 -eq $(($2)) ]]; then
    curl -s --location -g --request GET "${solr_url}/select?q=${q}&fl=orderNo&rows=${max_rows}" | \
    sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p'
  else
    get_orders $(( ($1+$2)/2 )) $2
    get_orders $1 $(( ($1+$2)/2 ))
  fi
}


#linux version
get_orders()
{
  start=`date -d @${1:0:-3} +%Y-%m-%dT%H:%M:%S.${1: -3}Z`
  end=`date -d @${2:0:-3} +%Y-%m-%dT%H:%M:%S.${2: -3}Z`
  q="path%3A1.Order%20AND%20orderDate%3A%5B${start}%20TO%20${end}%5D"
  cnt=`curl -s --location -g --request GET "${solr_url}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
  if [[ $((cnt)) -eq 0 ]]; then
    :
  elif [[ $((cnt)) -le $((max_rows)) ]] || [[ $(($1))+1 -eq $(($2)) ]]; then
    curl -s --location -g --request GET "${solr_url}/select?q=${q}&fl=orderNo&rows=${max_rows}" | \
    sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p'
  else
    get_orders $(( ($1+$2)/2 )) $2
    get_orders $1 $(( ($1+$2)/2 ))
  fi
}


tail=`date +%s000`
head=`date -v-5y "+%s000"`
#get_orders $head $tail > orders.txt

#or 
while [ $tail -gt $head ]
do
  let mark=$tail-86400000
  get_orders $mark $tail > $mark-$tail.txt
  tar zcf $mark-$tail.txt.gz $mark-$tail.txt
  rm $mark-$tail.txt
  let tail=$mark
done

> order_not_found.txt

while read order_no
do
curl -s --location --request GET "http://lookup-app.stg.order-services.cp.prod.walmart.com/orders-lookup/services/v4/orders?orderNo=${order_no}" \
--header 'Accept: application/json' \
--header 'Content-Type: application/json' \
--header 'WM_QOS.CORRELATION_ID: 2323' \
--header 'WM_SVC.VERSION: 4.0.0' \
--header 'WM_SVC.ENV: stg' \
--header 'WM_SVC.NAME: order-service' \
--header 'WM_CONSUMER.ID: 443842b5-b511-4428-96b1-509be82f3053' \
--header 'WM_CONSUMER.TENANT_ID: 0' \
--header 'Cache-Control: no-cache' \
--header 'Postman-Token: 4838e58c-c8dd-4f54-b4f1-e6ec145db772' | grep "${order_no}" > /dev/null || echo "$order_no"
done < orders.txt > order.not.found.txt


while read order_no
do
  curl -s -X POST -H "Content-Type: application/json" "${solr_url}/update" -d '{"delete":"'${order_no}'"}'
done < order.not.found.txt
