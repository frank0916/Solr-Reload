awk '{if ($2 > 0) {print $1}}' sc-missing.txt
