#this cluster was decommissioned
base_url=http://solrcloud.prod-az-southcentralus.order-services-primary-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_prod_new
o_s=156DAYS
g_s=79DAYS
t_s=3DAYS
q="(orderDate%3A%5B*%20TO%20NOW-${t_s}%5D%20AND%20isTestMode%3Atrue)%20OR%20(orderDate%3A%5B*%20TO%20NOW-${g_s}%5D%20AND%20verticalId%3A2)%20OR%20orderDate%3A%5B*%20TO%20NOW-${o_s}%5D&rows=1000&fl=idx"
part1="curl -s -X POST -H 'Content-Type: application/json' '${base_url}/update' -d '{"
part3="}'"
while true; do
    part2=`curl -s "${base_url}/select?q=${q}" | sed -n 's/^ *"idx":"\([^"]*\).*/"delete":"\1"/p' | paste -sd "," -`
    [ -z "${part2}" ] || eval ${part1}${part2}${part3}
    sleep 1
done

# ssh 10.102.120.30


# base_url=http://solrcloud.prod-az-southcentralus.order-services-primary-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_prod_new
# start_date='*'
# q="(orderDate%3A%5B${start_date}%20TO%20NOW-4MONTHS%5D%20AND%20verticalId%3A2)%20OR%20orderDate%3A%5B${start_date}%20TO%20NOW-6MONTHS%5D&rows=1000&fl=idx"
# part1="curl -s -X POST -H 'Content-Type: application/json' '${base_url}/update' -d '{"
# part3="}'"
# while true; do
#     part2=`curl -s "${base_url}/select?q=${q}" | sed -n 's/^ *"idx":"\([^"]*\).*/"delete":"\1"/p' | paste -sd "," -`
#     [ -z "${part2}" ] || eval ${part1}${part2}${part3}
#     sleep 1
# done

# #define start date for deletion, start_date='*'
# #or define start date in UTC format, start_date=2021-04-07T13:28:44Z
# #(orderDate:[* TO NOW-5MONTHS] AND verticalId:2) OR orderDate:[* TO NOW-6MONTHS]
# #q="(orderDate%3A%5B${start_date}%20TO%20NOW-5MONTHS%5D%20AND%20verticalId%3A2)%20OR%20orderDate%3A%5B${start_date}%20TO%20NOW-6MONTHS%5D&rows=1000&fl=idx"
# #q="orderDate%3A%5B${start_date}%20TO%20NOW-6MONTHS%5D%20OR%20(orderDate%3A%5B${start_date}%20TO%20NOW-5MONTHS%5D%20AND%20verticalId%3A2)&rows=1000&fl=idx"
# #test query in plain format with solr admin UI: (orderDate:[${start_date} TO NOW-5MONTHS] AND verticalId:2) OR orderDate:[${start_date} TO NOW-6MONTHS]
# #test query in encoded format with following link:
# #http://solrcloud.prod-dfw.order-services-primary4-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new/select?q=(orderDate%3A%5B*%20TO%20NOW-5MONTHS%5D%20AND%20verticalId%3A2)%20OR%20orderDate%3A%5B*%20TO%20NOW-6MONTHS%5D


# base_url=http://solrcloud.prod-az-southcentralus.order-services-primary-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_prod_new
# order=176DAYS
# grocery=79DAYS
# q="(orderDate%3A%5B*%20TO%20NOW-${grocery}%5D%20AND%20verticalId%3A2)%20OR%20orderDate%3A%5B*%20TO%20NOW-${order}%5D&rows=1000&fl=idx"
# part1="curl -s -X POST -H 'Content-Type: application/json' '${base_url}/update' -d '{"
# part3="}'"
# while true; do
#     part2=`curl -s "${base_url}/select?q=${q}" | sed -n 's/^ *"idx":"\([^"]*\).*/"delete":"\1"/p' | paste -sd "," -`
#     [ -z "${part2}" ] || eval ${part1}${part2}${part3}
#     sleep 1
# done



# base_url=http://solrcloud.prod-az-southcentralus.order-services-primary-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_prod_new
# order=176DAYS
# grocery=79DAYS
# q="(orderDate%3A%5B*%20TO%20NOW-${grocery}%5D%20AND%20verticalId%3A2)%20OR%20orderDate%3A%5B*%20TO%20NOW-${order}%5D&rows=1000&fl=idx"
# part1="curl -s -X POST -H 'Content-Type: application/json' '${base_url}/update' -d '{"
# part3="}'"
# while true; do
#     part2=`curl -s "${base_url}/select?q=${q}" | sed -n 's/^ *"idx":"\([^"]*\).*/"delete":"\1"/p' | paste -sd "," -`
#     [ -z "${part2}" ] || eval ${part1}${part2}${part3}
#     sleep 1
# done



# base_url=http://solrcloud.prod-az-southcentralus.order-services-primary-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_prod_new
# o_s=176DAYS
# g_s=79DAYS
# t_s=3DAYS
# q="(orderDate%3A%5B*%20TO%20NOW-${t_s}%5D%20AND%20isTestMode%3Atrue)%20OR%20(orderDate%3A%5B*%20TO%20NOW-${g_s}%5D%20AND%20verticalId%3A2)%20OR%20orderDate%3A%5B*%20TO%20NOW-${o_s}%5D&rows=1000&fl=idx"
# part1="curl -s -X POST -H 'Content-Type: application/json' '${base_url}/update' -d '{"
# part3="}'"
# while true; do
#     part2=`curl -s "${base_url}/select?q=${q}" | sed -n 's/^ *"idx":"\([^"]*\).*/"delete":"\1"/p' | paste -sd "," -`
#     [ -z "${part2}" ] || eval ${part1}${part2}${part3}
#     sleep 1
# done
