base_url=http://solrcloud.prod-az-westus2.order-services-primary-prod.ms-df-solrcloud.westus2.prod.us.walmart.net:8983/solr/orders_prod_new

save_order_numbers()
{
    cnt=0
    while read line
    do
        echo $line
        order_no=$line
        let cnt++
    done
}

echo_order_numbers()
{
    save_order_numbers
    [[ $cnt -lt 1000 ]] && return

    q="orderNo%3A${order_no}&fl=orderDate"
    order_date=`curl -s --location -g --request GET "${base_url}/select?q=${q}" | sed -n 's/.*"orderDate":"\([^"]*\).*/\1/p'`

    cnt=0
    q="orderDate%3A%5B${order_date}%20TO%20${order_date}%5D&rows=1000"
    curl -s --location -g --request GET "${base_url}/select?q=${q}" | sed -n 's/.*"idx":"\([^"]*\).*/\1/p' | save_order_numbers
    [[ $cnt -ge 1000 ]] && echo missing orders, too many order in timeslot ${order_date}

    query_order_date_range ${1} ${order_date}
}

query_order_date_range()
{
    q="orderDate%3A%5B${1}T00%3A57%3A51Z%20TO%20${2}T00%3A00%3A00Z%5D&rows=1000&sort=createts%20desc"
    curl -s --location -g --request GET "${base_url}/select?q=${q}" | sed -n 's/.*"idx":"\([^"]*\).*/\1/p' | echo_order_numbers ${1} ${2}
}

end=`date "+%Y-%m-%d"`
for i in {1..1}
do
    start=`date -v-${i}d "+%Y-%m-%d"`
    echo $start $end
    query_order_date_range ${start} ${end}
    end=$pre_d
done
