while read line
do
curl -s "http://solrcloud.prod-az-westus2.order-services-primary2-prod.ms-df-solrcloud.westus2.prod.us.walmart.net:8983/solr/orders_prod_new/select?q=id%3A${line}%20AND%20orderDate%3A%5BNOW-7DAYS%20TO%20NOW-2DAYS%5D&fl=orderNo"
done < sorted.all.txt