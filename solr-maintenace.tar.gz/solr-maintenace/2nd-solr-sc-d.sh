(orderDate:[* TO NOW-3YEARS] AND -deleteDate:[* TO *])
 OR
deleteDate:[* TO NOW]
 OR
(isTestMode:true AND orderDate:[* TO NOW-3DAYS])