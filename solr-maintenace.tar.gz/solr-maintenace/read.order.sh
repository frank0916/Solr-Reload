#starting of read.order.sh
get_orders()
{
  start=`date -d @${1:0:-3} +%Y-%m-%dT%H:%M:%S.${1: -3}Z`
  end=`date -d @${2:0:-3} +%Y-%m-%dT%H:%M:%S.${2: -3}Z`
  q="orderDate%3A%5B${start}%20TO%20${end}%5D"
  cnt=`curl -s --location -g --request GET "${solr_url}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
  if [[ $((cnt)) -eq 0 ]]; then
    :
  elif [[ $((cnt)) -le 1000 ]] || [[ $(($1))+1 -eq $(($2)) ]]; then
    curl -s --location -g --request GET "${solr_url}/select?q=${q}&fl=orderNo&rows=1000" | \
    sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p'
  else
    get_orders $(( ($1+$2)/2 )) $2
    get_orders $1 $(( ($1+$2)/2 ))
  fi
}

while read line; do ts=`date -d "$line" +%s`; get_orders ${ts}000 $(($ts+86400))000; done < dates-with-diff-ge-10.txt
#ending of read.order.sh
