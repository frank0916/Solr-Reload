base_url=http://solrcloud.prod-cdc.order-services-secondary4-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_hist_prod
q="orderDate:[*%20TO%20NOW-3YEARS]&rows=1000&fl=orderNo"
part1="curl -s -X POST -H 'Content-Type: application/xml' '${base_url}/update' -d '<delete>"
part3="</delete>'"
while true; do
    part2=`curl -s --location -g --request GET "${base_url}/select?q=${q}" | sed -n 's/^ *"orderNo":"\([^"]*\).*/<id>\1<\/id>/p' | paste -sd ' ' -`
    [ -z "${part2}" ] || eval ${part1}${part2}${part3}
    sleep 10
done
#stg lookup-app stg-cdc2 10.38.131.122 - DONE
