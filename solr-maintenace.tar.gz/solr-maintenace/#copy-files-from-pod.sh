#1 copy keystore.jks and truststore.jks from an e2e pod of return-order-services
sledge connect uswest-stage-az-003
#get pods
#kubectl describe namespaces return-order-services
kubectl get pods -n return-order-services
kubectl exec -it orders-consumer-e2e-5cddf6f786-qcws4 -n return-order-services -- /bin/bash
ls /var/lib/certs/
^D
kubectl exec -it orders-consumer-e2e-5cddf6f786-qcws4 -n return-order-services -- cp /var/lib/certs/kafka.client.truststore.jks kafka.client.truststore.jk
kubectl exec -it orders-consumer-e2e-5cddf6f786-qcws4 -n return-order-services -- cp /var/lib/certs/keystore.jks keystore.jks


#2 run java application
sledge connect eus2-dev-a3 #connect to cluster eus2-dev-a3
kubectl get pods -n order-services # get pods
kubectl exec -it orders-lookup-dev-7dfb57b567-vn7jd -n order-services -- /bin/bash #start bash
java -fullversion #verify java version 17 or higher

echo "message from cloud" | mail -s "system alert" qun.he@walmart.com


