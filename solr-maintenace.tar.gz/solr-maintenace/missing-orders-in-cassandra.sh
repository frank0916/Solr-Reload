while read order_no
do
curl -s --location --request GET "http://os-lookup.dev.walmart.com/orders-lookup/services/v4/orders?orderNo=${order_no}" \
--header 'Accept: application/json' \
--header 'Content-Type: application/json' \
--header 'WM_QOS.CORRELATION_ID: 2323' \
--header 'WM_SVC.VERSION: 4.0.0' \
--header 'WM_SVC.ENV: stg' \
--header 'WM_SVC.NAME: order-service' \
--header 'WM_CONSUMER.ID: 2d0a30c7-b4cc-45d1-b451-d93535f5a92d' \
--header 'WM_CONSUMER.TENANT_ID: 0' \
--header 'Cache-Control: no-cache' \
--header 'Postman-Token: 4838e58c-c8dd-4f54-b4f1-e6ec145db772' | grep ${order_no} > /dev/null
[[ $? ]] || echo ${order_no}
done < stg.solr.order-no. > missing-orders-in-cassandra.txt
