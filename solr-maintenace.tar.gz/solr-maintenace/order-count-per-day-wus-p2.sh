#see order-reload-wus-p2.sh
publish() {
    while read line
    do
      echo '{event_id:"'$line'",event_name:"RELOAD_ORDERS",event_source:"OMSNEXT"}' | \
      bin/kafka-console-producer.sh \
        --topic data-load-order-us \
        --bootstrap-server kafka-1173818850-1-1245094171.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-2-1245094174.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-3-1245094177.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-4-1245094180.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-5-1245094183.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-6-1245094186.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-7-1245094189.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-8-1245094192.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-9-1245094195.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-10-1245094198.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-11-1245094201.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-12-1245094204.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-13-1245094207.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-14-1245094210.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-15-1245094213.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092
    done
}

reload_orders()
{
  [[ $1+1 == $2 ]]
  start=`date -d @${1} +%Y-%m-%dT%H:%M:%SZ`
  end=`date -d @${2} +%Y-%m-%dT%H:%M:%SZ`
  q="orderDate%3A%5B${start}%20TO%20${end}%5D"
  cnt=`curl -s --location -g --request GET "${solr_url}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
  if [[ $((cnt)) -eq 0 ]]; then
    :
  elif [[ $((cnt)) -le 1000 ]] || [[ $(($1))+1 -eq $(($2)) ]]; then
    curl -s --location -g --request GET "${solr_url}/select?q=${q}&fl=orderNo&rows=1000" | \
    sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p' | \
    publish
  else
    echo split $cnt $1 $2
    reload_orders $(( ($1+$2)/2 )) $2
    reload_orders $1 $(( ($1+$2)/2 ))
  fi
}

let ts=`date +%s`
seconds_per_day=86400
for i in {0..179}
do
    let ts_pre_day=ts-seconds_per_day
    reload_orders $ts_pre_day $ts
    let ts=ts_pre_day
done | \
bin/kafka-console-producer.sh \
  --topic data-load-order-us \
  --bootstrap-server kafka-1173818850-1-1245094171.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-2-1245094174.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-3-1245094177.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-4-1245094180.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-5-1245094183.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-6-1245094186.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-7-1245094189.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-8-1245094192.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-9-1245094195.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-10-1245094198.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-11-1245094201.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-12-1245094204.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-13-1245094207.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-14-1245094210.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092,kafka-1173818850-15-1245094213.scus.kafka-v2-order-services-2-prod.ms-df-messaging.prod-az-southcentralus-27.prod.us.walmart.net:9092

#  1664582400 1668988800

#ssh 10.12.160.31
#-bash-4.2$ nohup ./order.reload.sh >/dev/null 2>&1 &
#[1] 12640

#https://www.epochconverter.com/
#get date in seconds
#date +%s
#date +%s -d"Jan 1, 1980 00:00:01" Replace '-d' with '-ud' to input in GMT/UTC time.

#convert epoch long integer to Solr date format
#date -d @${$1} +%Y-%m-%dT%H:%M:%SZ

#get orderNo from Solr and publish following message to Kafka
#insertAllOrder in ConsumerBizImpl.insertAllOrder(String message)
#'{event_id:"'$line'",event_name:"RELOAD_ORDERS",event_source:"OMSNEXT"}'


#-bash-4.2$ nohup ./new.order.reload.sh >/dev/null 2>&1 &
#[1] 24468

# https://stackoverflow.com/questions/49187200/convert-linux-date-to-yyyy-mm-ddthhmmssz-format
