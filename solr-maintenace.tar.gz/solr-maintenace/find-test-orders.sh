function write_orders() {
    cursorMark=*
    while true; do
        response=`curl -s -X GET "$base_url/select?&q=$q&cursorMark=${cursorMark}"`
        nextCursorMark=$(echo "$response" | sed -n 's/.*"nextCursorMark":"\([^"]*\)".*/\1/p')
        [[ -e ${nextCursorMark} ]] && continue
        [[ "${nextCursorMark}" == "${cursorMark}" ]] && break
        cursorMark=${nextCursorMark}
        echo ${response} | grep -oE '"orderNo":"[0-9A-Za-z]*' | awk -F'"' '{print $4}' >> ${1}
    done
}

start_day=$(date -d "-10 days" "+%Y-%m-%d")
end_day=$(date -d "-0 days" "+%Y-%m-%d")

base_url=http://solrcloud.prod-az-southcentralus.order-services-secondary-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_hist_prod
q="(orderDate%3A%5B${start_day}T00:00:00Z%20TO%20${end_day}T00:00:00Z%5D%20AND%20isTestMode=true)&sort=orderNo%20asc&fl=orderNo&rows=1000"
write_orders testing-orders.txt
