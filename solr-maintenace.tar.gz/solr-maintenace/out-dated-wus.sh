base_url=http://solrcloud.prod-az-westus.order-services-primary-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_prod_new
start_date='*'
q="(orderDate%3A%5B${start_date}%20TO%20NOW-4MONTHS%5D%20AND%20verticalId%3A2)%20OR%20orderDate%3A%5B${start_date}%20TO%20NOW-6MONTHS%5D&rows=1000&fl=idx"
part1="curl -s -X POST -H 'Content-Type: application/json' '${base_url}/update' -d '{"
part3="}'"
while true; do
    part2=`curl -s "${base_url}/select?q=${q}" | sed -n 's/^ *"idx":"\([^"]*\).*/"delete":"\1"/p' | paste -sd "," -`
    [ -z "${part2}" ] || eval ${part1}${part2}${part3}
    sleep 1
done

#define start date for deletion, start_date='*'
#or define start date in UTC format, start_date=2021-04-07T13:28:44Z
#(orderDate:[* TO NOW-5MONTHS] AND verticalId:2) OR orderDate:[* TO NOW-6MONTHS]
#q="(orderDate%3A%5B${start_date}%20TO%20NOW-5MONTHS%5D%20AND%20verticalId%3A2)%20OR%20orderDate%3A%5B${start_date}%20TO%20NOW-6MONTHS%5D&rows=1000&fl=idx"
#q="orderDate%3A%5B${start_date}%20TO%20NOW-6MONTHS%5D%20OR%20(orderDate%3A%5B${start_date}%20TO%20NOW-5MONTHS%5D%20AND%20verticalId%3A2)&rows=1000&fl=idx"
#test query in plain format with solr admin UI: (orderDate:[${start_date} TO NOW-5MONTHS] AND verticalId:2) OR orderDate:[${start_date} TO NOW-6MONTHS]
#test query in encoded format with following link:
#http://solrcloud.prod-dfw.order-services-primary4-prod.ms-df-solrcloud.prod.walmart.com:8983/solr/orders_prod_new/select?q=(orderDate%3A%5B*%20TO%20NOW-5MONTHS%5D%20AND%20verticalId%3A2)%20OR%20orderDate%3A%5B*%20TO%20NOW-6MONTHS%5D
#q=(orderDate%3A%5B*%20TO%20NOW-4MONTHS%2B14DAYS%5D%20AND%20verticalId%3A2)%20OR%20orderDate%3A%5B*%20TO%20NOW-6MONTHS%5D
#q=(orderDate%3A%5B*%20TO%20NOW-4MONTHS%2B14DAYS%5D%20AND%20verticalId%3A2)%20OR%20orderDate%3A%5B*%20TO%20NOW-180DAYS%5D

#q=(orderDate%3A%5B*%20TO%20NOW-120DAYS%5D%20AND%20verticalId%3A2)%20OR%20orderDate%3A%5B*%20TO%20NOW-180DAYS%5D