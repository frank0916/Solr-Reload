
#download files from lenses with partition number and time or position

sed -e 's/"orderNo":"/\n/g' LSQL-messages-2024-01-26-19-16-17.json | sed 's/\([^"]*\).*/\1/' | sort | uniq -c | sort -nr
