url_1=http://solrcloud.prod-az-westus2.order-services-primary2-prod.ms-df-solrcloud.westus2.prod.us.walmart.net:8983/solr/orders_prod_new
url_2=http://solrcloud.prod-az-eastus2.order-services-primary2-dr-prod.ms-df-solrcloud.prod.us.walmart.net:8983/solr/orders_prod_new

rm -rf logs
mkdir logs

echo creating logs/start.end.date.txt> logs/log.txt
python3 generate-start-end-date-list.py -s ${url_1} -t ${url_2} > logs/start.end.date.txt

max_rows=1000

get_orders()
{
  start=`date -d @${1:0:-3} +%Y-%m-%dT%H:%M:%S.${1: -3}Z`
  end=`date -d @${2:0:-3} +%Y-%m-%dT%H:%M:%S.${2: -3}Z`
  q="path%3A1.Order%20AND%20orderDate%3A%5B${start}%20TO%20${end}%5D"
  cnt=`curl -s --location -g --request GET "${solr_url}/select?q=${q}&rows=0" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
  if [[ $((cnt)) -eq 0 ]]; then
    :
  elif [[ $((cnt)) -le $((max_rows)) ]] || [[ $(($1))+1 -eq $(($2)) ]]; then
    curl -s --location -g --request GET "${solr_url}/select?q=${q}&fl=orderNo&rows=${max_rows}" | \
    sed -n 's/^ *"orderNo":"\([^"]*\).*/\1/p'
  else
    get_orders $(( ($1+$2)/2 )) $2
    get_orders $1 $(( ($1+$2)/2 ))
  fi
}


while read start_ts end_ts
do
    solr_url=${url_1}
    get_orders ${start_ts}000 ${end_ts}000 > 1.$start_ts.$end_ts.txt
    sort 1.$start_ts.$end_ts.txt | uniq > 1.$start_ts.$end_ts.uniq.txt

    solr_url=${url_2}
    get_orders ${start_ts}000 ${end_ts}000 > 2.$start_ts.$end_ts.txt
    sort 2.$start_ts.$end_ts.txt | uniq > 2.$start_ts.$end_ts.uniq.txt

    comm -23 1.$start_ts.$end_ts.uniq.txt 2.$start_ts.$end_ts.uniq.txt > diff-$start_ts.$end_ts.txt
    #python3 order_reload.py < diff-$start_ts.$end_ts.txt > log.diff-$start_ts.$end_ts.txt
done < seconds-pairs.txt
