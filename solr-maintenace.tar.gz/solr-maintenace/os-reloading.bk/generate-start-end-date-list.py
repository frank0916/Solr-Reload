# how to run: python3 get-reload-start-end-timestamp-list.py -s ${url_1} -t ${url_2} > start_ts.end_ts.txt

import argparse
import requests
import json
from datetime import date, timedelta, datetime

parser = argparse.ArgumentParser(
    description='Solr orderNo check by reading orderNo from stdin'
)
parser.add_argument(
    '-s', '--source',
    metavar='SOURCE',
    required=True,
    help="Solr url for source to compare"
)
parser.add_argument(
    '-t', '--target',
    metavar='TARGET',
    required=True,
    help="Solr url for target to compare"
)

args = parser.parse_args()
url_s = args.source
url_t = args.target

to_day = date.today()
for i in range(183):
    from_day = to_day - timedelta(1)
    params = {
        'q': f'orderDate:[{from_day}T00:00:00Z TO {to_day}T00:00:00Z]', 'rows':0
    }
    response_1 = requests.get(
        url_s + '/select',
        params=params
    )
    response_2 = requests.get(
        url_t + '/select',
        params=params
    )

    json_1 = json.loads(response_1.text)
    json_2 = json.loads(response_2.text)

    cnt_1 = json_1['response']['numFound']
    cnt_2 = json_2['response']['numFound']

    diff = cnt_1 - cnt_2

    if diff > 100:
        print(from_day, to_day)

    to_day = from_day

