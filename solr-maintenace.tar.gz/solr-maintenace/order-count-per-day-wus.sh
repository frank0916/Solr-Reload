base_url=http://solrcloud.prod-az-westus2.order-services-primary-prod.ms-df-solrcloud.westus2.prod.us.walmart.net:8983/solr/orders_prod_new

print_solr_count()
{
    q="orderDate%3A%5B$20${1}T00%3A00%3A00Z%20TO%20${2}T00%3A00%3A00Z%5D&rows=0"
    cnt=`curl -s --location -g --request GET "${base_url}/select?q=${q}" | sed -n 's/.*"numFound":\([0-9]*\).*/\1/p'`
    echo ${cnt},${1}
}

d=`date "+%Y-%m-%d"`
for i in {1..180}
do
    pre_d=`date -v-${i}d "+%Y-%m-%d"`
    print_solr_count ${pre_d} ${d}
    d=$pre_d
done
