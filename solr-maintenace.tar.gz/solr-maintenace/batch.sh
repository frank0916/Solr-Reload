while read date_line
do
  s_seconds=`date -d"$date_line" +%s`
  e_seconds=$(( s_seconds + 86400 ))
  ./order.reload.sh ${s_seconds}000 ${e_seconds}000
done < dates.txt

#e_date=2022-11-05
#ets=`date -d ${end_date} +%s`
#seconds_per_day=86400

#generate date list descending date
#seconds_per_day=86400
#e_day=2022-11-05
#cts=`date -d ${e_day} +%s`
#for i in {1..10}
#do
#    date -d @$cts +%Y-%m-%d
#    let cts=cts-seconds_per_day
#done > dates.txt
