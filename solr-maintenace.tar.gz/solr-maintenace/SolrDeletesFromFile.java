package com.walmart.scos.services.orders.biz.test;

import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.DefaultConnectionReuseStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultConnectionKeepAliveStrategy;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.CloudSolrClient;
import org.apache.solr.client.solrj.response.UpdateResponse;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.io.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * File created by Ahmed Hamdy at 6/23/2021.
 */
public class SolrDeletesFromFile {

    private final static ArrayList<String> allOrderNo = new ArrayList<String>();
    static Map<String, CloudSolrClient> solr_dc_map = new HashMap<String, CloudSolrClient>();
    static ExecutorService executorService = Executors.newFixedThreadPool(1);
    public static final String DELETE_TERMS_QUERY = "{!terms f=_root_}";

    private static Integer firstStepSize = 1000000;
    private static Integer secondStepSize = 5000000;
    private final static Integer deleteBatchSize = 10000000;

    private static long overall_Count = 0L;

    public static void main(String[] args) throws IOException, SolrServerException, InterruptedException {
        solrDocDeletion();
    }

    @RequestMapping(value = "/solrDocDeletion", method = RequestMethod.GET, produces = "application/json")
    public static void solrDocDeletion() throws SolrServerException, IOException, InterruptedException {

        buildSolrDCMap();

        //Files which have the OrderNos to be deleted.
        String[] fileNameslist = {
            "GR-Orders-Docs-Delete-12-23-2020-to-01-23-2021.txt",
            "set1.txtaa",
            "set1.txtab",
            "set1.txtac",
            "set1.txtad",
            "set1.txtae",
            "set2.xaa",
            "set2.xab",
            "set2.xac",
            "set2.xad",
            "set2.xae"
        };

        long start = System.currentTimeMillis();
        for (String fileName : fileNameslist) {
            //local filepath to be updated below
            String filePath = "/Users/vn51f8s/solr-records-deletion/split/" + fileName;
            try (Scanner scanner = new Scanner(new File(filePath));) {
                while (scanner.hasNextLine()) {
                    String row = scanner.nextLine();
                    allOrderNo.add(row);
                }
            } catch (Exception e) {
                System.out.println("Exception while reading file " + e.getStackTrace());
            }

            if (solr_dc_map.size() > 0 && allOrderNo.size()>0) {
                long startTime = System.currentTimeMillis();
                deleteDoc();
                long endTime = System.currentTimeMillis();
                System.out.println("Total Time to delete all the IDs: " + (endTime - startTime));
                System.out.println("Deleted orders from File " + fileName + " with order count " + allOrderNo.size() + " with Time taken in millis : " + (System.currentTimeMillis() - start));
                TimeUnit.SECONDS.sleep(10);

            }
            allOrderNo.clear();
        }
        System.out.println("Total Time to delete orders from all files: " + overall_Count + " with Time taken in millis : " + (System.currentTimeMillis() - start));

    }

    private static void buildSolrDCMap() {
        CloudSolrClient solrClient_dc1 = null;

        //az-westus - this is just example of zookeeper hosts
        String zkhost1 = "solr-zk-8534-3-864286.prod-az-westus.order-services-primary2-prod.ms-df-solrcloud.prod-az--7.prod.us.walmart.net:2181,solr-zk-853453271-6-864288295.prod-az-.order-services-primary2-prod.ms-df-solrcloud.prod-az--7.prod.us.walmart.net:2181,solr-zk-853453271-5-864288292.prod-az-.order-services-primary2-prod.ms-df-solrcloud.prod-az--7.prod.us.walmart.net:2181,solr-zk-853453271-1-864288280.prod-az-.order-services-primary2-prod.ms-df-solrcloud.prod-az--7.prod.us.walmart.net:2181,solr-zk-853453271-2-864288283.prod-az-.order-services-primary2-prod.ms-df-solrcloud.prod-az--7.prod.us.walmart.net:2181,solr-zk-853453271-4-864288289.prod-az-.order-services-primary2-prod.ms-df-solrcloud.prod-az--7.prod.us.walmart.net:2181";
        String collName1 = "orders_collection_name"; // this is also need to replaced with real collection name

        if (zkhost1 != null && !zkhost1.equals("") && collName1 != null && !collName1.equals("")) {
            solrClient_dc1 = new CloudSolrClient.Builder().withZkHost(zkhost1).withHttpClient(getHttpClient()).build();
            solr_dc_map.put(collName1, solrClient_dc1);
        }
        System.out.println("Solr DC Map size =" + solr_dc_map.size());
    }

    public static void deleteDoc() throws SolrServerException, IOException {
        StringBuilder deleteString = new StringBuilder(DELETE_TERMS_QUERY);
        int loopEnd = allOrderNo.size();
        if (firstStepSize <= loopEnd) {
            loopEnd = firstStepSize;
        }
        for (int i = 0; i < loopEnd; i++) {
            deleteString.append(allOrderNo.get(i) + ",");
        }
        deleteString.deleteCharAt(deleteString.length() - 1);
        deleteFromAllSolrClusters(deleteString.toString(), firstStepSize);
        deleteString = new StringBuilder(DELETE_TERMS_QUERY);
        if ((secondStepSize + firstStepSize) <= allOrderNo.size()) {
            loopEnd = secondStepSize + firstStepSize;

        }
        for (int i = firstStepSize; i < loopEnd; i++) {
            deleteString.append(allOrderNo.get(i) + ",");
        }
        deleteString.deleteCharAt(deleteString.length() - 1);
        deleteFromAllSolrClusters(deleteString.toString(), secondStepSize);
        deleteString = new StringBuilder(DELETE_TERMS_QUERY);
        for (int i = firstStepSize + secondStepSize; i < allOrderNo.size(); i++) {
            if ((i - firstStepSize + secondStepSize + 1) % deleteBatchSize == 0) {
                deleteString.deleteCharAt(deleteString.length() - 1);
                deleteFromAllSolrClusters(deleteString.toString(), deleteBatchSize);
                deleteString = new StringBuilder(DELETE_TERMS_QUERY);
            }
            deleteString.append(allOrderNo.get(i) + ",");
        }
        if (deleteString.length() > 17) {
            deleteString.deleteCharAt(deleteString.length() - 1);
            deleteFromAllSolrClusters(deleteString.toString(), deleteBatchSize);
        }
    }

    public static void deleteFromAllSolrClusters(String deleteString, int batchSize) {
        try {
            List<Future<Boolean>> futures = new ArrayList<Future<Boolean>>();
            for (String key : solr_dc_map.keySet()) {
                futures.add(executorService.submit(() -> {
                    try {
                        System.out.println("Deleting Data");
                        UpdateResponse res = solr_dc_map.get(key).deleteByQuery(key, deleteString);
                        System.out.println("Primary Solr Collection- " + key + " for batch size " + batchSize +
                                " Delete_Query_Time =" + res.getQTime());
                    } catch (Exception e) {
                        System.out.println("Error while deleting data from PRIMARY Solr-Cloud-" + solr_dc_map.get(key));
                    }
                    return true;
                }));
            }
            for (Future<Boolean> future : futures) {
                future.get();
            }
        } catch (Exception e) {
            System.out.println("Error while deleting data from PRIMARY Solr-Cloud");
        }
    }

    private static HttpClient getHttpClient() {
        RequestConfig rc = RequestConfig.custom().setConnectTimeout(500000)
                .setConnectionRequestTimeout(500000)
                .setSocketTimeout(500000).build();
        HttpClientBuilder httpClientBuilder = HttpClients.custom()
                .setDefaultRequestConfig(rc)
                .disableAutomaticRetries()
                .setConnectionReuseStrategy(new DefaultConnectionReuseStrategy())
                .setKeepAliveStrategy(new DefaultConnectionKeepAliveStrategy())
                .setConnectionTimeToLive(1, TimeUnit.MINUTES);
        CloseableHttpClient httpClient = httpClientBuilder.build();
        return httpClient;
    }
}